# Seminário de Algoritmo Avançado — 4 temas

| Tema | Aplicação | Java (interface interativa) | Python |
|---|---|---|---|
| Busca Bidirecional | Rota urbana (BFS vs bidirecional) | `bidirecional/java` | `bidirecional/python` |
| Hill Climbing | Rota de distribuição (TSP) | `hill_climbing/java` | `hill_climbing/python` |
| Floyd-Warshall | Rede de transportes e centro logístico | `floyd_warshall/java` (usa `package floydwarshall`) | `floyd_warshall/python` |
| Colónia de Formigas | Rota de recolha de resíduos (TSP) | `colonia_formigas/java` | `colonia_formigas/python` |

Cada pasta tem um `README.md` com instruções e um quadro de conteúdos alinhado com os critérios de avaliação.
Capturas de exemplo em `imagens/`. Os projectos Java de Bidirecional, Hill Climbing e Colónia **não usam `package`**:
basta copiar os `.java` de `src` para o `src` do IDE e executar `Main`.

**Requisitos:** JDK 11+ e/ou Python 3.8+ com `matplotlib`. Atalho: `./compilar_java.sh`.
