#!/bin/sh
for d in bidirecional hill_climbing colonia_formigas; do
  (cd $d/java && mkdir -p out && javac -encoding UTF-8 -d out src/*.java && echo "OK $d  ->  java -cp $d/java/out Main")
done
(cd floyd_warshall/java && mkdir -p out && javac -encoding UTF-8 -d out src/floydwarshall/*.java && echo "OK floyd_warshall -> java -cp floyd_warshall/java/out floydwarshall.Main")
