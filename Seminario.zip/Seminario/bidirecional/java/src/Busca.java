import java.util.*;

/** BFS clássica e Busca Bidirecional. Regista a ordem de descoberta das células (para a animação). */
public class Busca {

    public static class Resultado {
        public String nome;
        public List<Integer> caminho;                       // null se não existe
        public List<int[]> eventos = new ArrayList<>();     // {célula, lado}: lado 0 = desde a origem, 1 = desde o destino
        public int expandidos;
    }

    private static int[] novo(int n) { int[] a = new int[n]; Arrays.fill(a, -1); return a; }

    private static List<Integer> raiz(int[] pai, int x) {   // [x, pai[x], ..., raiz]
        List<Integer> r = new ArrayList<>();
        for (; x != -1; x = pai[x]) r.add(x);
        return r;
    }

    public static Resultado bfs(Grade g) {
        int s = g.origem(), t = g.destino(), n = g.n();
        int[] d = novo(n), p = novo(n);
        Deque<Integer> q = new ArrayDeque<>();
        Resultado res = new Resultado();
        res.nome = "BFS clássica";
        d[s] = 0; q.add(s); res.eventos.add(new int[]{s, 0});
        while (!q.isEmpty()) {
            int u = q.poll(); res.expandidos++;
            if (u == t) { List<Integer> c = raiz(p, u); Collections.reverse(c); res.caminho = c; break; }
            for (int v : g.vizinhos(u))
                if (d[v] < 0) { d[v] = d[u] + 1; p[v] = u; q.add(v); res.eventos.add(new int[]{v, 0}); }
        }
        return res;
    }

    public static Resultado bidirecional(Grade g) {
        int s = g.origem(), t = g.destino(), n = g.n();
        Resultado res = new Resultado();
        res.nome = "Bidirecional";
        res.eventos.add(new int[]{s, 0});
        res.eventos.add(new int[]{t, 1});
        if (s == t) { res.caminho = new ArrayList<>(Arrays.asList(s)); return res; }
        int[] dF = novo(n), dB = novo(n), pF = novo(n), pB = novo(n);
        Deque<Integer> qF = new ArrayDeque<>(), qB = new ArrayDeque<>();
        dF[s] = 0; dB[t] = 0; qF.add(s); qB.add(t);
        while (!qF.isEmpty() && !qB.isEmpty()) {
            boolean frente = qF.size() <= qB.size();          // expande a fronteira mais pequena
            Deque<Integer> q = frente ? qF : qB;
            int[] d = frente ? dF : dB, p = frente ? pF : pB, dO = frente ? dB : dF;
            int lado = frente ? 0 : 1;
            int melhor = Integer.MAX_VALUE, mu = -1, mv = -1;
            for (int k = q.size(); k > 0; k--) {               // um nível completo
                int u = q.poll(); res.expandidos++;
                for (int v : g.vizinhos(u)) {
                    if (dO[v] >= 0) {                          // as fronteiras tocam-se
                        int custo = d[u] + 1 + dO[v];
                        if (custo < melhor) { melhor = custo; mu = u; mv = v; }
                    }
                    if (d[v] < 0) { d[v] = d[u] + 1; p[v] = u; q.add(v); res.eventos.add(new int[]{v, lado}); }
                }
            }
            if (mu >= 0) {
                int a = frente ? mu : mv, b = frente ? mv : mu;
                List<Integer> c = raiz(pF, a);
                Collections.reverse(c);
                c.addAll(raiz(pB, b));
                res.caminho = c;
                break;
            }
        }
        return res;
    }
}
