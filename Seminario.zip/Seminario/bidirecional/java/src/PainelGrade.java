import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/** Desenha lado a lado a BFS e a Busca Bidirecional; permite editar o mapa com o rato. */
public class PainelGrade extends JPanel {

    public enum Ferramenta { PAREDE, BORRACHA, ORIGEM, DESTINO }

    private static final int MARGEM = 15, TOPO = 40, RODAPE = 50;
    private final Grade grade;
    private Busca.Resultado[] resultados;
    private int passo = Integer.MAX_VALUE;           // nº de eventos revelados (animação)
    private Ferramenta ferramenta = Ferramenta.PAREDE;
    private Runnable aoEditar = () -> { };
    private int celula = 10;
    private final int[] ox = new int[2];

    public PainelGrade(Grade grade) {
        this.grade = grade;
        setBackground(Color.WHITE);
        MouseAdapter m = new MouseAdapter() {
            @Override public void mousePressed(MouseEvent e) { aplicar(e); }
            @Override public void mouseDragged(MouseEvent e) { aplicar(e); }
        };
        addMouseListener(m);
        addMouseMotionListener(m);
    }

    public void setFerramenta(Ferramenta f) { ferramenta = f; }
    public void setAoEditar(Runnable r) { aoEditar = r; }
    public void setResultados(Busca.Resultado[] r) { resultados = r; repaint(); }
    public Busca.Resultado[] getResultados() { return resultados; }
    public void setPasso(int p) { passo = p; repaint(); }
    public int getPasso() { return passo; }

    public int maxEventos() {
        int m = 0;
        if (resultados != null) for (Busca.Resultado r : resultados) m = Math.max(m, r.eventos.size());
        return m;
    }

    private void calcularLayout() {
        celula = Math.max(3, Math.min((getWidth() - 3 * MARGEM) / 2 / grade.colunas,
                                      (getHeight() - TOPO - RODAPE) / grade.linhas));
        for (int k = 0; k < 2; k++) ox[k] = MARGEM + k * (grade.colunas * celula + MARGEM);
    }

    private void aplicar(MouseEvent e) {
        calcularLayout();
        for (int k = 0; k < 2; k++) {
            int x = e.getX() - ox[k], y = e.getY() - TOPO;
            if (x < 0 || y < 0) continue;
            int c = x / celula, r = y / celula;
            if (r >= grade.linhas || c >= grade.colunas) continue;
            Ferramenta f = SwingUtilities.isRightMouseButton(e) ? Ferramenta.BORRACHA : ferramenta;
            boolean eOrigem = r == grade.oL && c == grade.oC, eDestino = r == grade.dL && c == grade.dC;
            switch (f) {
                case PAREDE:  if (!eOrigem && !eDestino) grade.parede[r][c] = true; break;
                case BORRACHA: grade.parede[r][c] = false; break;
                case ORIGEM:  if (!eDestino) { grade.oL = r; grade.oC = c; grade.parede[r][c] = false; } break;
                case DESTINO: if (!eOrigem) { grade.dL = r; grade.dC = c; grade.parede[r][c] = false; } break;
            }
            aoEditar.run();
            repaint();
            return;
        }
    }

    @Override
    protected void paintComponent(Graphics g0) {
        super.paintComponent(g0);
        Graphics2D g = (Graphics2D) g0;
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        calcularLayout();
        for (int k = 0; k < 2; k++) {
            Busca.Resultado r = resultados == null ? null : resultados[k];
            byte[] est = new byte[grade.n()];
            int vis = 0;
            if (r != null) {
                vis = Math.min(passo, r.eventos.size());
                for (int i = 0; i < vis; i++) { int[] e = r.eventos.get(i); est[e[0]] |= (e[1] == 0 ? 1 : 2); }
            }
            boolean terminou = r != null && passo >= r.eventos.size();
            String titulo = r == null ? (k == 0 ? "BFS clássica" : "Busca Bidirecional")
                    : r.nome + ": " + vis + " células descobertas" + (terminou ? " | " + r.expandidos + " nós expandidos" : "");
            g.setColor(Color.BLACK);
            g.setFont(new Font("SansSerif", Font.BOLD, 14));
            g.drawString(titulo, ox[k], 25);

            for (int row = 0; row < grade.linhas; row++)
                for (int c = 0; c < grade.colunas; c++) {
                    int id = grade.id(row, c);
                    Color cor = Color.WHITE;
                    if (est[id] == 1) cor = new Color(180, 217, 255);
                    else if (est[id] == 2) cor = new Color(255, 209, 153);
                    else if (est[id] == 3) cor = new Color(204, 140, 242);
                    if (grade.parede[row][c]) cor = new Color(51, 51, 51);
                    g.setColor(cor);
                    g.fillRect(ox[k] + c * celula, TOPO + row * celula, celula, celula);
                    if (celula >= 8) {
                        g.setColor(new Color(225, 225, 225));
                        g.drawRect(ox[k] + c * celula, TOPO + row * celula, celula, celula);
                    }
                }
            if (terminou && r.caminho != null) {
                g.setColor(Color.RED);
                g.setStroke(new BasicStroke(Math.max(2f, celula / 4f)));
                for (int i = 0; i + 1 < r.caminho.size(); i++) {
                    int a = r.caminho.get(i), b = r.caminho.get(i + 1);
                    g.drawLine(ox[k] + grade.coluna(a) * celula + celula / 2, TOPO + grade.linha(a) * celula + celula / 2,
                               ox[k] + grade.coluna(b) * celula + celula / 2, TOPO + grade.linha(b) * celula + celula / 2);
                }
            }
            g.setColor(new Color(0, 160, 0));
            g.fillOval(ox[k] + grade.oC * celula, TOPO + grade.oL * celula, celula, celula);
            g.setColor(Color.BLUE);
            g.fillOval(ox[k] + grade.dC * celula, TOPO + grade.dL * celula, celula, celula);
        }
        g.setColor(Color.BLACK);
        g.setFont(new Font("SansSerif", Font.PLAIN, 12));
        int y = TOPO + grade.linhas * celula + 20;
        g.drawString("Verde = origem | Azul = destino | Azul claro = descoberto desde a origem | Laranja = desde o destino | Roxo = ambos", MARGEM, y);
        g.drawString("Vermelho = caminho mais curto | Cinza escuro = parede | Clique/arraste para editar (botão direito apaga)", MARGEM, y + 16);
    }
}
