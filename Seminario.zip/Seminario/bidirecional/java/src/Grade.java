import java.util.*;

/** Mapa em grelha editável: paredes, origem e destino. */
public class Grade {
    public static final String[] MAPA_EXEMPLO = {
        ".#....#.......#.............#......#.....",
        "..........#..............................",
        "#..................#............#........",
        ".....................#..#................",
        "........#.....#....#.........#...........",
        "....#..................#.................",
        ".......#......#.....#..........#...#..#..",
        ".........##....#.................#.......",
        "##...............#..#....................",
        "....................#....................",
        "..##................#....................",
        "..................#.#....................",
        ".....#..............#....#...#....#......",
        ".......#...........##...#................",
        ".....#..#.#.........##..........#.....##.",
        ".........#..........#...........#...#....",
        "..................#.#....#...............",
        "...#..#.......#.....#....................",
        "..................##............#........",
        ".............#..................#........",
        "........S.......................G#.......",
        "...#....................#................",
        "...................#.....................",
        "............#................#..........#",
        "....................#................#...",
        "........#...........#....#..#..#.#.......",
        "....................#....#...............",
        ".#..................#...#...............#",
        "....................#........#..##.......",
        ".#..................#.............##.....",
        "...........#..#.....#....................",
        ".............#.....##....................",
        ".........#.........##........#...........",
        ".........................................",
        "....#...........#.........#......#...#...",
        "......#.........#......................#.",
        "....................#.....#..............",
        "...#.....................................",
        "....#.................#..................",
        ".........#......#........................",
        ".#............#.........#................"
    };

    public int linhas, colunas, oL, oC, dL, dC;
    public boolean[][] parede;

    public Grade() { carregarExemplo(); }

    public void carregarExemplo() {
        linhas = MAPA_EXEMPLO.length; colunas = MAPA_EXEMPLO[0].length();
        parede = new boolean[linhas][colunas];
        for (int r = 0; r < linhas; r++)
            for (int c = 0; c < colunas; c++) {
                char ch = MAPA_EXEMPLO[r].charAt(c);
                if (ch == '#') parede[r][c] = true;
                if (ch == 'S') { oL = r; oC = c; }
                if (ch == 'G') { dL = r; dC = c; }
            }
    }

    public void limparParedes() { parede = new boolean[linhas][colunas]; }

    public void redimensionar(int l, int c) {
        boolean[][] n = new boolean[l][c];
        for (int r = 0; r < Math.min(l, linhas); r++)
            for (int k = 0; k < Math.min(c, colunas); k++) n[r][k] = parede[r][k];
        parede = n; linhas = l; colunas = c;
        oL = Math.min(oL, l - 1); oC = Math.min(oC, c - 1);
        dL = Math.min(dL, l - 1); dC = Math.min(dC, c - 1);
        if (oL == dL && oC == dC) { dL = l - 1; dC = c - 1; if (oL == dL && oC == dC) { oL = 0; oC = 0; } }
        parede[oL][oC] = false; parede[dL][dC] = false;
    }

    public void aleatorio(int percentagem, long semente) {
        Random rng = new Random(semente);
        for (int r = 0; r < linhas; r++)
            for (int c = 0; c < colunas; c++) parede[r][c] = rng.nextInt(100) < percentagem;
        parede[oL][oC] = false; parede[dL][dC] = false;
    }

    public int n() { return linhas * colunas; }
    public int id(int r, int c) { return r * colunas + c; }
    public int linha(int id) { return id / colunas; }
    public int coluna(int id) { return id % colunas; }
    public int origem() { return id(oL, oC); }
    public int destino() { return id(dL, dC); }
    public boolean parede(int id) { return parede[linha(id)][coluna(id)]; }

    public int[] vizinhos(int id) {
        int r = linha(id), c = coluna(id);
        int[][] d = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
        int[] tmp = new int[4];
        int k = 0;
        for (int[] x : d) {
            int nr = r + x[0], nc = c + x[1];
            if (nr >= 0 && nr < linhas && nc >= 0 && nc < colunas && !parede[nr][nc]) tmp[k++] = id(nr, nc);
        }
        return Arrays.copyOf(tmp, k);
    }
}
