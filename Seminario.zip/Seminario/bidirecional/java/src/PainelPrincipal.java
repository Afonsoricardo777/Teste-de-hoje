import javax.swing.*;
import java.awt.*;

/** Janela de controlo: ferramentas de edição, geração de mapas, execução e animação. */
public class PainelPrincipal extends JPanel {

    private final Grade grade = new Grade();
    private final PainelGrade painel = new PainelGrade(grade);
    private final JLabel estado = new JLabel(" ");
    private final JSlider velocidade = new JSlider(1, 60, 10);
    private final Timer timer = new Timer(30, e -> tique());
    private final JButton pausar = new JButton("Pausar");
    private final JSpinner sLin = new JSpinner(new SpinnerNumberModel(grade.linhas, 5, 80, 1));
    private final JSpinner sCol = new JSpinner(new SpinnerNumberModel(grade.colunas, 5, 80, 1));
    private final JSpinner sDens = new JSpinner(new SpinnerNumberModel(20, 0, 60, 5));

    public PainelPrincipal() {
        setLayout(new BorderLayout());

        // --- linha 1: edição do mapa ---
        JPanel l1 = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 4));
        ButtonGroup bg = new ButtonGroup();
        l1.add(new JLabel("Ferramenta:"));
        for (PainelGrade.Ferramenta f : PainelGrade.Ferramenta.values()) {
            JToggleButton b = new JToggleButton(nome(f), f == PainelGrade.Ferramenta.PAREDE);
            b.addActionListener(e -> painel.setFerramenta(f));
            bg.add(b); l1.add(b);
        }
        l1.add(new JLabel("  Linhas:")); l1.add(sLin);
        l1.add(new JLabel("Colunas:")); l1.add(sCol);
        JButton aplicar = new JButton("Aplicar tamanho");
        aplicar.addActionListener(e -> { grade.redimensionar((Integer) sLin.getValue(), (Integer) sCol.getValue()); editado(); });
        l1.add(aplicar);
        l1.add(new JLabel("  Densidade %:")); l1.add(sDens);
        JButton gerar = new JButton("Gerar aleatório");
        gerar.addActionListener(e -> { grade.aleatorio((Integer) sDens.getValue(), System.nanoTime()); editado(); });
        l1.add(gerar);
        JButton exemplo = new JButton("Mapa exemplo");
        exemplo.addActionListener(e -> {
            grade.carregarExemplo(); sLin.setValue(grade.linhas); sCol.setValue(grade.colunas); editado();
        });
        JButton limpar = new JButton("Limpar paredes");
        limpar.addActionListener(e -> { grade.limparParedes(); editado(); });

        // --- linha 2: execução ---
        JPanel l2 = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 4));
        JButton exec = new JButton("Executar");
        exec.addActionListener(e -> executarInstantaneo());
        JButton animar = new JButton("▶ Animar");
        animar.addActionListener(e -> animar());
        pausar.addActionListener(e -> {
            if (timer.isRunning()) { timer.stop(); pausar.setText("Continuar"); }
            else if (painel.getResultados() != null && painel.getPasso() < painel.maxEventos()) { timer.start(); pausar.setText("Pausar"); }
        });
        JButton limparRes = new JButton("Limpar resultado");
        limparRes.addActionListener(e -> editado());
        l2.add(exec); l2.add(animar); l2.add(pausar); l2.add(limparRes);
        l2.add(new JLabel("  Velocidade:")); l2.add(velocidade);
        l2.add(exemplo); l2.add(limpar);

        JPanel topo = new JPanel();
        topo.setLayout(new BoxLayout(topo, BoxLayout.Y_AXIS));
        topo.add(l1); topo.add(l2);
        add(topo, BorderLayout.NORTH);
        add(painel, BorderLayout.CENTER);
        estado.setBorder(BorderFactory.createEmptyBorder(4, 8, 6, 8));
        estado.setFont(estado.getFont().deriveFont(Font.BOLD, 13f));
        add(estado, BorderLayout.SOUTH);

        painel.setAoEditar(this::editado);
        estado.setText("Edite o mapa (paredes, origem, destino) e clique em Executar ou Animar.");
    }

    private static String nome(PainelGrade.Ferramenta f) {
        switch (f) {
            case PAREDE: return "Parede";
            case BORRACHA: return "Borracha";
            case ORIGEM: return "Origem";
            default: return "Destino";
        }
    }

    private void editado() {
        if (timer != null) timer.stop();
        pausar.setText("Pausar");
        painel.setResultados(null);
        estado.setText("Mapa alterado. Clique em Executar ou Animar.");
        painel.repaint();
    }

    private void calcular() {
        painel.setResultados(new Busca.Resultado[]{Busca.bfs(grade), Busca.bidirecional(grade)});
    }

    public void executarInstantaneo() {
        timer.stop();
        calcular();
        painel.setPasso(Integer.MAX_VALUE);
        atualizarEstado();
    }

    private void animar() {
        timer.stop();
        calcular();
        painel.setPasso(0);
        pausar.setText("Pausar");
        estado.setText("A animar...");
        timer.start();
    }

    private void tique() {
        int p = painel.getPasso() + velocidade.getValue();
        if (p >= painel.maxEventos()) { timer.stop(); painel.setPasso(Integer.MAX_VALUE); atualizarEstado(); }
        else painel.setPasso(p);
    }

    private void atualizarEstado() {
        Busca.Resultado a = painel.getResultados()[0], b = painel.getResultados()[1];
        if (a.caminho == null) {
            estado.setText("Sem caminho possível: a origem e o destino não estão ligados.");
            return;
        }
        double red = 100.0 * (1 - (double) b.expandidos / a.expandidos);
        estado.setText(String.format("BFS: %d nós expandidos | Bidirecional: %d nós expandidos | caminho de %d passos (igual nos dois) | redução: %.0f%%",
                a.expandidos, b.expandidos, a.caminho.size() - 1, red));
    }

    public String resumo() { return estado.getText(); }
}
