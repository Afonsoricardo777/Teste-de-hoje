"""Busca Bidirecional (BFS bidirecional) numa grelha urbana."""
from collections import deque

MAPA = [
    '.#....#.......#.............#......#.....',
    '..........#..............................',
    '#..................#............#........',
    '.....................#..#................',
    '........#.....#....#.........#...........',
    '....#..................#.................',
    '.......#......#.....#..........#...#..#..',
    '.........##....#.................#.......',
    '##...............#..#....................',
    '....................#....................',
    '..##................#....................',
    '..................#.#....................',
    '.....#..............#....#...#....#......',
    '.......#...........##...#................',
    '.....#..#.#.........##..........#.....##.',
    '.........#..........#...........#...#....',
    '..................#.#....#...............',
    '...#..#.......#.....#....................',
    '..................##............#........',
    '.............#..................#........',
    '........S.......................G#.......',
    '...#....................#................',
    '...................#.....................',
    '............#................#..........#',
    '....................#................#...',
    '........#...........#....#..#..#.#.......',
    '....................#....#...............',
    '.#..................#...#...............#',
    '....................#........#..##.......',
    '.#..................#.............##.....',
    '...........#..#.....#....................',
    '.............#.....##....................',
    '.........#.........##........#...........',
    '.........................................',
    '....#...........#.........#......#...#...',
    '......#.........#......................#.',
    '....................#.....#..............',
    '...#.....................................',
    '....#.................#..................',
    '.........#......#........................',
    '.#............#.........#................'
]  # '#' = obstáculo (edifício/rua cortada), '.' = livre, S = origem, G = destino

VIZINHOS = [(1, 0), (-1, 0), (0, 1), (0, -1)]


class Resultado:
    def __init__(self, nome, caminho, frente, tras, expandidos):
        self.nome = nome
        self.caminho = caminho        # lista de (linha, coluna) ou None
        self.frente = frente          # células descobertas pela busca a partir da origem
        self.tras = tras              # células descobertas pela busca a partir do destino
        self.expandidos = expandidos  # nº de nós retirados da fila


def carregar(mapa=MAPA):
    grelha = [list(l) for l in mapa]
    s = g = None
    for r, linha in enumerate(grelha):
        for c, x in enumerate(linha):
            if x == 'S': s = (r, c)
            if x == 'G': g = (r, c)
    return grelha, s, g


def vizinhos(grelha, p):
    r, c = p
    for dr, dc in VIZINHOS:
        nr, nc = r + dr, c + dc
        if 0 <= nr < len(grelha) and 0 <= nc < len(grelha[0]) and grelha[nr][nc] != '#':
            yield (nr, nc)


def _raiz(pai, x):
    """Segue os pais de x até à raiz: [x, pai[x], ..., raiz]."""
    r = []
    while x is not None:
        r.append(x)
        x = pai[x]
    return r


def bfs(grelha, s, g):
    """BFS clássica (para comparação). Complexidade O(b^d)."""
    dist, pai, fila, exp = {s: 0}, {s: None}, deque([s]), 0
    while fila:
        u = fila.popleft()
        exp += 1
        if u == g:
            return Resultado("BFS clássica", _raiz(pai, u)[::-1], set(dist), set(), exp)
        for v in vizinhos(grelha, u):
            if v not in dist:
                dist[v], pai[v] = dist[u] + 1, u
                fila.append(v)
    return Resultado("BFS clássica", None, set(dist), set(), exp)


def bidirecional(grelha, s, g):
    """Duas BFS em simultâneo (origem->destino e destino->origem) até se encontrarem.
    Complexidade O(b^(d/2)) em cada sentido. Expande-se sempre a fronteira mais pequena,
    um nível completo de cada vez (garante o caminho óptimo em grafos não ponderados)."""
    if s == g:
        return Resultado("Bidirecional", [s], {s}, {g}, 0)
    dF, dB, pF, pB = {s: 0}, {g: 0}, {s: None}, {g: None}
    qF, qB, exp = deque([s]), deque([g]), 0
    while qF and qB:
        frente = len(qF) <= len(qB)
        fila, d, p, dO = (qF, dF, pF, dB) if frente else (qB, dB, pB, dF)
        melhor = None
        for _ in range(len(fila)):                 # um nível completo
            u = fila.popleft()
            exp += 1
            for v in vizinhos(grelha, u):
                if v in dO:                         # as duas fronteiras tocam-se
                    custo = d[u] + 1 + dO[v]
                    if melhor is None or custo < melhor[0]:
                        melhor = (custo, u, v)
                if v not in d:
                    d[v], p[v] = d[u] + 1, u
                    fila.append(v)
        if melhor:
            _, u, v = melhor
            a, b = (u, v) if frente else (v, u)    # a: lado da origem, b: lado do destino
            caminho = _raiz(pF, a)[::-1] + _raiz(pB, b)
            return Resultado("Bidirecional", caminho, set(dF), set(dB), exp)
    return Resultado("Bidirecional", None, set(dF), set(dB), exp)


def desenhar_ascii(grelha, res):
    """Representação estrutural em texto: f = visitada pela frente, b = por trás, * = caminho."""
    out = [list(l) for l in grelha]
    for (r, c) in res.frente:
        if out[r][c] == '.': out[r][c] = 'f'
    for (r, c) in res.tras:
        out[r][c] = 'X' if out[r][c] == 'f' else ('b' if out[r][c] == '.' else out[r][c])
    for (r, c) in (res.caminho or []):
        if out[r][c] in '.fbX': out[r][c] = '*'
    return '\n'.join(''.join(l) for l in out)
