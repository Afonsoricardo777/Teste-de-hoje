"""Rota urbana com Busca Bidirecional vs BFS clássica.
Uso:  python main.py            (mostra janela)
      python main.py --png f.png (grava imagem)
      python main.py --ascii     (só texto)"""
import sys
from algoritmo import carregar, bfs, bidirecional, desenhar_ascii


def relatorio(res):
    n = len(res.caminho) - 1 if res.caminho else None
    print(f"{res.nome:14s} | passos no caminho: {n} | nós expandidos: {res.expandidos}")


def grafico(grelha, resultados, ficheiro=None):
    import matplotlib
    if ficheiro: matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import numpy as np
    fig, eixos = plt.subplots(1, 2, figsize=(14, 7.5))
    for ax, res in zip(eixos, resultados):
        img = np.ones((len(grelha), len(grelha[0]), 3))
        for r, linha in enumerate(grelha):
            for c, x in enumerate(linha):
                if x == '#': img[r, c] = (0.2, 0.2, 0.2)
        for (r, c) in res.frente: img[r, c] = (0.70, 0.85, 1.0)      # azul: a partir da origem
        for (r, c) in res.tras:                                       # laranja: a partir do destino
            img[r, c] = (0.80, 0.55, 0.95) if (r, c) in res.frente else (1.0, 0.82, 0.60)
        for r, linha in enumerate(grelha):
            for c, x in enumerate(linha):
                if x == '#': img[r, c] = (0.2, 0.2, 0.2)
        ax.imshow(img)
        if res.caminho:
            ax.plot([c for r, c in res.caminho], [r for r, c in res.caminho], 'r-', lw=2.5)
        s, g = res.caminho[0], res.caminho[-1]
        ax.plot(s[1], s[0], 'go', ms=11); ax.plot(g[1], g[0], 'b*', ms=15)
        ax.set_title(f"{res.nome}: {res.expandidos} nós expandidos")
        ax.set_xticks([]); ax.set_yticks([])
    fig.suptitle("Azul = pesquisa desde a origem | Laranja = desde o destino | Roxo = ambas | Vermelho = caminho")
    plt.tight_layout()
    if ficheiro: fig.savefig(ficheiro, dpi=110); print("Imagem gravada em", ficheiro)
    else: plt.show()


if __name__ == "__main__":
    grelha, s, g = carregar()
    r1, r2 = bfs(grelha, s, g), bidirecional(grelha, s, g)
    relatorio(r1); relatorio(r2)
    print(f"Redução de nós expandidos: {100 * (1 - r2.expandidos / r1.expandidos):.0f}%\n")
    print(desenhar_ascii(grelha, r2))
    if "--ascii" not in sys.argv:
        ficheiro = sys.argv[sys.argv.index("--png") + 1] if "--png" in sys.argv else None
        grafico(grelha, [r1, r2], ficheiro)
