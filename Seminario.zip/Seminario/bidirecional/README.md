# Busca Bidirecional — Rota urbana interativa (Tema 8)

**Aplicação:** caminho mais curto entre dois pontos de uma cidade (grelha com obstáculos), comparando **BFS clássica** e **Busca Bidirecional**.

## Java (interface interativa)
`cd java && mkdir out && javac -encoding UTF-8 -d out src/*.java && java -cp out Main`
(sem `package`: copie todos os `.java` de `src` para o `src` do seu IDE e execute `Main`; `--png f.png` grava imagem sem janela).

Na janela: escolha a ferramenta **Parede / Borracha / Origem / Destino** e clique ou arraste no mapa (botão direito apaga);
altere o **tamanho** da grelha; gere um mapa **aleatório** (densidade %); **Executar** mostra o resultado, **Animar** mostra as duas
buscas a crescer ao mesmo tempo (ajuste a velocidade, use Pausar). A barra de estado compara os nós expandidos.

## Python (visualização estática)
`cd python && pip install -r requirements.txt && python main.py [--png f.png | --ascii]`

**Ideia:** duas BFS em simultâneo (da origem e do destino) até as fronteiras se tocarem; expande-se sempre a fronteira mais pequena, um nível completo
de cada vez. Mapa de exemplo: mesmo caminho (24 passos), **832 → 442 nós expandidos (−47%)**.

| Critério | Conteúdo sugerido |
|---|---|
| Definição e objectivos | Procurar em dois sentidos para reduzir o espaço explorado; óptimo em grafos não ponderados. |
| Potencialidades | O(b^(d/2)) em vez de O(b^d); grande poupança em grafos grandes (redes sociais, GPS, puzzles). |
| Limitações | Exige destino **conhecido** e arestas **reversíveis**; memória para duas fronteiras; com pesos é mais delicado; ganho pequeno em corredores estreitos (teste desenhar um corredor na janela). |
| Exemplo prático | `Busca.java` / `algoritmo.py`. |
| Representação gráfica | Azul (da origem), laranja (do destino), roxo (ambos), vermelho (caminho). |
