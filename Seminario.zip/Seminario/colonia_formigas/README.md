# Colónia de Formigas (ACO) — Rota de recolha de resíduos (Tema 25)

**Aplicação:** ordem de visita de 15 bairros por um camião de recolha (Caixeiro Viajante), minimizando os km.

**Java (interface interativa):** `cd java && mkdir out && javac -encoding UTF-8 -d out src/*.java && java -cp out Main`
(sem `package`: copie todos os `.java` de `src` para o `src` do seu IDE e execute `Main`).
Na janela: altere formigas, α, β, ρ e nº de iterações; clique **1 iteração** ou **Executar**; clique no mapa para adicionar
bairros e com o botão direito para remover; veja a feromona (traço vermelho grosso) e o gráfico de convergência.
`java -cp out Main --png f.png` grava uma imagem sem janela.

**Python:** `cd python && pip install -r requirements.txt && python main.py [--formigas 20 --iteracoes 100 --alfa 1 --beta 3 --rho 0.5 --png f.png]`

**Ideia (Ant System):** cada formiga escolhe o próximo bairro com probabilidade ∝ τᵅ·(1/d)ᵝ; no fim da iteração a feromona evapora
(τ ← (1−ρ)τ) e cada formiga deposita Q/L nas arestas da sua rota (rotas curtas → mais feromona).
No mapa de exemplo: **322,2 km** (igual ao óptimo exacto calculado por Held-Karp) contra 369,3 km do vizinho mais próximo (−12,8%).

| Critério | Conteúdo sugerido |
|---|---|
| Definição e objectivos | Meta-heurística inspirada no comportamento de formigas que marcam caminhos com feromona (Dorigo, 1992). |
| Potencialidades | Boa para problemas de rotas/grafos; explora muitas soluções em paralelo; adapta-se a mudanças no mapa; resultados próximos do óptimo; feromona = memória colectiva. |
| Limitações | Não garante o óptimo; sensível aos parâmetros (α, β, ρ — experimente alterá-los na janela); convergência lenta em instâncias grandes; pode estagnar numa rota (use ρ maior); custo O(iterações · formigas · n²). |
| Exemplo prático | `algoritmo.py` / `ColoniaFormigas.java`. |
| Representação gráfica | Mapa com feromona e melhor rota + curva de convergência. |
