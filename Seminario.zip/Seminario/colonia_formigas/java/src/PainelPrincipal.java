import javax.swing.*;
import java.awt.*;

/** Janela de controlo da Colónia de Formigas: parâmetros, execução e visualização da feromona. */
public class PainelPrincipal extends JPanel {

    private final ColoniaFormigas cf = new ColoniaFormigas();
    private final PainelMapa mapa = new PainelMapa(cf);
    private final PainelGrafico grafico = new PainelGrafico(cf);
    private final JLabel estado = new JLabel(" ");
    private final JSpinner sFormigas = new JSpinner(new SpinnerNumberModel(20, 1, 200, 1));
    private final JSpinner sIter = new JSpinner(new SpinnerNumberModel(100, 1, 2000, 10));
    private final JSpinner sAlfa = new JSpinner(new SpinnerNumberModel(1.0, 0.0, 10.0, 0.1));
    private final JSpinner sBeta = new JSpinner(new SpinnerNumberModel(3.0, 0.0, 10.0, 0.1));
    private final JSpinner sRho = new JSpinner(new SpinnerNumberModel(0.5, 0.01, 0.99, 0.05));
    private final JSpinner sBairros = new JSpinner(new SpinnerNumberModel(15, 4, 60, 1));
    private final JSlider velocidade = new JSlider(1, 30, 12);
    private final JButton pausar = new JButton("Pausar");
    private final Timer timer = new Timer(60, e -> tique());
    private int alvo;

    public PainelPrincipal() {
        setLayout(new BorderLayout());

        JPanel l1 = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 4));
        l1.add(new JLabel("Formigas:")); l1.add(sFormigas);
        l1.add(new JLabel("α (feromona):")); l1.add(sAlfa);
        l1.add(new JLabel("β (distância):")); l1.add(sBeta);
        l1.add(new JLabel("ρ (evaporação):")); l1.add(sRho);
        l1.add(new JLabel("Iterações:")); l1.add(sIter);

        JPanel l2 = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 4));
        JButton passo = new JButton("1 iteração");
        passo.addActionListener(e -> { parar(); iterarUma(); });
        JButton exec = new JButton("▶ Executar");
        exec.addActionListener(e -> { lerParametros(); alvo = cf.iteracao + (Integer) sIter.getValue(); pausar.setText("Pausar"); timer.start(); });
        pausar.addActionListener(e -> {
            if (timer.isRunning()) { timer.stop(); pausar.setText("Continuar"); }
            else if (cf.iteracao < alvo) { timer.start(); pausar.setText("Pausar"); }
        });
        JButton reset = new JButton("Reiniciar feromona");
        reset.addActionListener(e -> { parar(); cf.reiniciar(); atualizar(); });
        l2.add(passo); l2.add(exec); l2.add(pausar); l2.add(reset);
        l2.add(new JLabel("  Velocidade:")); l2.add(velocidade);
        JCheckBox cbF = new JCheckBox("Mostrar feromona", true), cbM = new JCheckBox("Mostrar melhor rota", true);
        cbF.addActionListener(e -> { mapa.mostrarFeromona = cbF.isSelected(); mapa.repaint(); });
        cbM.addActionListener(e -> { mapa.mostrarMelhor = cbM.isSelected(); mapa.repaint(); });
        l2.add(cbF); l2.add(cbM);

        JPanel l3 = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 4));
        l3.add(new JLabel("Bairros:")); l3.add(sBairros);
        JButton gerar = new JButton("Gerar aleatórios");
        gerar.addActionListener(e -> { parar(); cf.gerarAleatorios((Integer) sBairros.getValue()); atualizar(); });
        JButton exemplo = new JButton("Mapa exemplo (15 bairros)");
        exemplo.addActionListener(e -> { parar(); cf.carregarExemplo(); atualizar(); });
        JButton limpar = new JButton("Limpar mapa");
        limpar.addActionListener(e -> { parar(); cf.limpar(); atualizar(); });
        l3.add(gerar); l3.add(exemplo); l3.add(limpar);

        JPanel topo = new JPanel();
        topo.setLayout(new BoxLayout(topo, BoxLayout.Y_AXIS));
        topo.add(l1); topo.add(l2); topo.add(l3);
        add(topo, BorderLayout.NORTH);
        add(mapa, BorderLayout.CENTER);
        grafico.setPreferredSize(new Dimension(440, 320));
        add(grafico, BorderLayout.EAST);
        estado.setBorder(BorderFactory.createEmptyBorder(4, 8, 6, 8));
        estado.setFont(estado.getFont().deriveFont(Font.BOLD, 13f));
        add(estado, BorderLayout.SOUTH);

        mapa.setAoAlterar(() -> { parar(); atualizar(); });
        atualizar();
    }

    private void parar() { timer.stop(); pausar.setText("Pausar"); }

    private void lerParametros() {
        cf.nFormigas = (Integer) sFormigas.getValue();
        cf.alfa = (Double) sAlfa.getValue();
        cf.beta = (Double) sBeta.getValue();
        cf.rho = (Double) sRho.getValue();
    }

    private void iterarUma() { lerParametros(); cf.iterar(); atualizar(); }

    private void tique() {
        timer.setDelay(Math.max(5, 600 / velocidade.getValue()));
        if (cf.iteracao >= alvo) { timer.stop(); return; }
        iterarUma();
    }

    private void atualizar() {
        if (cf.melhorRota == null) estado.setText("Bairros: " + cf.pontos.size() + " | clique em Executar ou 1 iteração."
                + (cf.rotaGulosa != null ? String.format(" | referência (vizinho mais próximo): %.1f km", cf.custoGuloso) : ""));
        else estado.setText(String.format("Iteração %d | melhor rota: %.1f km | vizinho mais próximo: %.1f km | melhoria: %.1f%%",
                cf.iteracao, cf.melhorCusto, cf.custoGuloso, 100 * (1 - cf.melhorCusto / cf.custoGuloso)));
        mapa.repaint(); grafico.repaint();
    }

    public void demonstracao(int iteracoes) { lerParametros(); for (int i = 0; i < iteracoes; i++) cf.iterar(); atualizar(); }
    public String resumo() { return estado.getText(); }
}
