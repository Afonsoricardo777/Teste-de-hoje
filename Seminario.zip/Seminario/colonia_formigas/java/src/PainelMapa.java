import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/** Mapa dos bairros com a feromona (traço grosso = mais feromona) e a melhor rota. */
public class PainelMapa extends JPanel {
    private static final int M = 40;
    private final ColoniaFormigas cf;
    public boolean mostrarFeromona = true, mostrarMelhor = true;
    private Runnable aoAlterar = () -> { };

    public PainelMapa(ColoniaFormigas cf) {
        this.cf = cf;
        setBackground(new Color(245, 245, 245));
        addMouseListener(new MouseAdapter() {
            @Override public void mousePressed(MouseEvent e) {
                int i = maisProximo(e.getX(), e.getY(), 14);
                if (SwingUtilities.isRightMouseButton(e)) { if (i >= 0) { cf.remover(i); aoAlterar.run(); } }
                else if (i < 0) {
                    cf.adicionar(1.0 * (e.getX() - M) * 100 / (getWidth() - 2 * M), 100 - 1.0 * (e.getY() - M) * 100 / (getHeight() - 2 * M));
                    aoAlterar.run();
                }
            }
        });
    }

    public void setAoAlterar(Runnable r) { aoAlterar = r; }
    private int px(double x) { return M + (int) (x * (getWidth() - 2 * M) / 100); }
    private int py(double y) { return M + (int) ((100 - y) * (getHeight() - 2 * M) / 100); }

    private int maisProximo(int x, int y, int raio) {
        int m = -1; double menor = raio;
        for (int i = 0; i < cf.pontos.size(); i++) {
            double dd = Point.distance(x, y, px(cf.pontos.get(i)[0]), py(cf.pontos.get(i)[1]));
            if (dd < menor) { menor = dd; m = i; }
        }
        return m;
    }

    @Override
    protected void paintComponent(Graphics g0) {
        super.paintComponent(g0);
        Graphics2D g = (Graphics2D) g0;
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        int n = cf.pontos.size();
        g.setFont(new Font("SansSerif", Font.BOLD, 13));
        g.setColor(Color.BLACK);
        g.drawString(n < 3 ? "Clique no mapa para adicionar bairros (mínimo 3)"
                : "Vermelho = feromona | Verde = melhor rota | clique esq.: adiciona bairro | clique dir.: remove", 10, 20);
        if (n >= 3 && mostrarFeromona) {
            double max = 0;
            for (int i = 0; i < n; i++) for (int j = i + 1; j < n; j++) max = Math.max(max, cf.tau[i][j]);
            for (int i = 0; i < n; i++)
                for (int j = i + 1; j < n; j++) {
                    double f = cf.tau[i][j] / max;
                    if (f > 0.04) {
                        g.setColor(new Color(220, 40, 40, (int) (255 * Math.min(1, 0.15 + f))));
                        g.setStroke(new BasicStroke((float) (0.5 + 6 * f)));
                        g.drawLine(px(cf.pontos.get(i)[0]), py(cf.pontos.get(i)[1]), px(cf.pontos.get(j)[0]), py(cf.pontos.get(j)[1]));
                    }
                }
        }
        if (n >= 3 && mostrarMelhor && cf.melhorRota != null) {
            g.setColor(new Color(0, 150, 0));
            g.setStroke(new BasicStroke(3f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 10f, new float[]{8f, 5f}, 0f));
            for (int k = 0; k < n; k++) {
                double[] a = cf.pontos.get(cf.melhorRota[k]), b = cf.pontos.get(cf.melhorRota[(k + 1) % n]);
                g.drawLine(px(a[0]), py(a[1]), px(b[0]), py(b[1]));
            }
        }
        g.setFont(new Font("SansSerif", Font.PLAIN, 11));
        for (int i = 0; i < n; i++) {
            int x = px(cf.pontos.get(i)[0]), y = py(cf.pontos.get(i)[1]);
            g.setColor(Color.BLACK); g.fillOval(x - 6, y - 6, 12, 12);
            g.drawString(cf.nomes.get(i), x + 8, y - 6);
        }
    }
}
