import java.util.*;

/** Motor da Colónia de Formigas (Ant System) para o Caixeiro Viajante - recolha de resíduos entre bairros. */
public class ColoniaFormigas {

    public static final String[] NOMES_EXEMPLO = {"Cazenga", "Viana", "Cacuaco", "Maianga", "Ingombota", "Sambizanga",
            "Rangel", "Kilamba", "Talatona", "Benfica", "Samba", "Mutamba", "Golfe", "Palanca", "Camama"};
    public static final int[][] PONTOS_EXEMPLO = {
        {62, 76},
        {64, 62},
        {70, 80},
        {29, 28},
        {70, 65},
        {85, 83},
        {28, 17},
        {62, 43},
        {23, 16},
        {73, 93},
        {86, 10},
        {81, 55},
        {62, 88},
        {83, 88},
        {25, 84}
    };

    public final List<double[]> pontos = new ArrayList<>();
    public final List<String> nomes = new ArrayList<>();
    public int nFormigas = 20;
    public double alfa = 1.0, beta = 3.0, rho = 0.5, q = 100.0;

    public double[][] tau, d;
    public int iteracao;
    public int[] melhorRota, rotaGulosa;
    public double melhorCusto = Double.POSITIVE_INFINITY, custoGuloso;
    public final List<Double> histIter = new ArrayList<>(), histMedia = new ArrayList<>(), histGlobal = new ArrayList<>();
    private final Random rng = new Random(42);

    public ColoniaFormigas() { carregarExemplo(); }

    // ---- gestão dos pontos (qualquer alteração reinicia a feromona) ----
    public void carregarExemplo() {
        pontos.clear(); nomes.clear();
        for (int i = 0; i < PONTOS_EXEMPLO.length; i++) {
            pontos.add(new double[]{PONTOS_EXEMPLO[i][0], PONTOS_EXEMPLO[i][1]});
            nomes.add(NOMES_EXEMPLO[i]);
        }
        reiniciar();
    }

    public void gerarAleatorios(int n) {
        pontos.clear(); nomes.clear();
        for (int i = 0; i < n; i++) { pontos.add(new double[]{5 + rng.nextInt(91), 5 + rng.nextInt(91)}); nomes.add("P" + (i + 1)); }
        reiniciar();
    }

    public void adicionar(double x, double y) { pontos.add(new double[]{x, y}); nomes.add("P" + (pontos.size())); reiniciar(); }
    public void remover(int i) { pontos.remove(i); nomes.remove(i); reiniciar(); }
    public void limpar() { pontos.clear(); nomes.clear(); reiniciar(); }

    /** Repõe a feromona inicial e apaga o histórico. */
    public void reiniciar() {
        int n = pontos.size();
        d = new double[n][n];
        for (int i = 0; i < n; i++) for (int j = 0; j < n; j++) d[i][j] = Math.hypot(pontos.get(i)[0] - pontos.get(j)[0], pontos.get(i)[1] - pontos.get(j)[1]);
        tau = new double[n][n];
        for (double[] l : tau) Arrays.fill(l, 1.0);
        iteracao = 0; melhorRota = null; melhorCusto = Double.POSITIVE_INFINITY;
        histIter.clear(); histMedia.clear(); histGlobal.clear();
        rotaGulosa = null; custoGuloso = 0;
        if (n >= 3) { rotaGulosa = vizinhoMaisProximo(0); custoGuloso = custo(rotaGulosa); }
    }

    public double custo(int[] r) {
        double t = 0;
        for (int i = 0; i < r.length; i++) t += d[r[i]][r[(i + 1) % r.length]];
        return t;
    }

    private int[] vizinhoMaisProximo(int inicio) {
        int n = pontos.size();
        int[] r = new int[n]; boolean[] usado = new boolean[n];
        r[0] = inicio; usado[inicio] = true;
        for (int k = 1; k < n; k++) {
            int melhor = -1;
            for (int j = 0; j < n; j++) if (!usado[j] && (melhor < 0 || d[r[k - 1]][j] < d[r[k - 1]][melhor])) melhor = j;
            r[k] = melhor; usado[melhor] = true;
        }
        return r;
    }

    /** Uma formiga constrói uma rota: P(i->j) proporcional a tau^alfa * (1/d)^beta. */
    private int[] construirRota() {
        int n = pontos.size();
        int[] r = new int[n]; boolean[] usado = new boolean[n];
        int atual = rng.nextInt(n);
        r[0] = atual; usado[atual] = true;
        for (int k = 1; k < n; k++) {
            double[] w = new double[n]; double soma = 0;
            for (int j = 0; j < n; j++) if (!usado[j]) { w[j] = Math.pow(tau[atual][j], alfa) * Math.pow(1.0 / d[atual][j], beta); soma += w[j]; }
            double x = rng.nextDouble() * soma; int escolhido = -1;
            for (int j = 0; j < n; j++) if (!usado[j]) { escolhido = j; x -= w[j]; if (x <= 0) break; }
            r[k] = escolhido; usado[escolhido] = true; atual = escolhido;
        }
        return r;
    }

    /** Uma iteração completa: construção, evaporação e depósito de feromona. */
    public void iterar() {
        int n = pontos.size();
        if (n < 3) return;
        int[][] rotas = new int[nFormigas][];
        double[] custos = new double[nFormigas];
        double soma = 0, melhorIt = Double.POSITIVE_INFINITY;
        for (int a = 0; a < nFormigas; a++) {
            rotas[a] = construirRota(); custos[a] = custo(rotas[a]); soma += custos[a];
            melhorIt = Math.min(melhorIt, custos[a]);
            if (custos[a] < melhorCusto) { melhorCusto = custos[a]; melhorRota = rotas[a].clone(); }
        }
        for (int i = 0; i < n; i++) for (int j = 0; j < n; j++) tau[i][j] = Math.max(tau[i][j] * (1 - rho), 1e-6);  // evaporação
        for (int a = 0; a < nFormigas; a++) {                                                                   // depósito
            double dep = q / custos[a];
            for (int k = 0; k < n; k++) { int x = rotas[a][k], y = rotas[a][(k + 1) % n]; tau[x][y] += dep; tau[y][x] += dep; }
        }
        iteracao++;
        histIter.add(melhorIt); histMedia.add(soma / nFormigas); histGlobal.add(melhorCusto);
    }
}
