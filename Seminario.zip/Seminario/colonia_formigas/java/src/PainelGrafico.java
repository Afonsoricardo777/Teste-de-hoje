import javax.swing.*;
import java.awt.*;
import java.util.List;

/** Convergência: média das formigas, melhor da iteração, melhor global e referência gulosa. */
public class PainelGrafico extends JPanel {
    private final ColoniaFormigas cf;

    public PainelGrafico(ColoniaFormigas cf) {
        this.cf = cf;
        setBackground(Color.WHITE);
        setPreferredSize(new Dimension(430, 300));
    }

    private void linha(Graphics2D g, List<Double> l, Color cor, float larg, int ox, int oy, int w, int h, double min, double max, int maxIt) {
        g.setColor(cor); g.setStroke(new BasicStroke(larg));
        for (int i = 0; i + 1 < l.size(); i++)
            g.drawLine(ox + i * w / maxIt, oy + (int) ((max - l.get(i)) / (max - min) * h),
                       ox + (i + 1) * w / maxIt, oy + (int) ((max - l.get(i + 1)) / (max - min) * h));
    }

    @Override
    protected void paintComponent(Graphics g0) {
        super.paintComponent(g0);
        Graphics2D g = (Graphics2D) g0;
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setFont(new Font("SansSerif", Font.BOLD, 12));
        g.setColor(Color.BLACK);
        g.drawString("Convergência", 10, 18);
        int ox = 62, oy = 30, w = getWidth() - ox - 15, h = getHeight() - oy - 55;
        g.drawRect(ox, oy, w, h);
        if (cf.histMedia.isEmpty()) { g.drawString("(execute iterações)", ox + 10, oy + 20); return; }
        double max = cf.custoGuloso, min = Double.MAX_VALUE;
        for (double c : cf.histMedia) max = Math.max(max, c);
        for (double c : cf.histGlobal) min = Math.min(min, c);
        min = Math.min(min, cf.histIter.stream().min(Double::compare).get());
        if (max <= min) max = min + 1;
        int maxIt = Math.max(1, cf.histMedia.size() - 1);
        linha(g, cf.histMedia, Color.GRAY, 1.5f, ox, oy, w, h, min, max, maxIt);
        linha(g, cf.histIter, new Color(40, 90, 220), 1.5f, ox, oy, w, h, min, max, maxIt);
        linha(g, cf.histGlobal, Color.RED, 3f, ox, oy, w, h, min, max, maxIt);
        if (cf.custoGuloso > 0) {
            int yg = oy + (int) ((max - cf.custoGuloso) / (max - min) * h);
            g.setColor(new Color(255, 140, 0));
            g.setStroke(new BasicStroke(1.5f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 10f, new float[]{6f, 4f}, 0f));
            g.drawLine(ox, yg, ox + w, yg);
        }
        g.setFont(new Font("SansSerif", Font.PLAIN, 11));
        g.setColor(Color.BLACK);
        g.drawString(String.format("%.0f km", max), 8, oy + 10);
        g.drawString(String.format("%.0f km", min), 8, oy + h);
        g.drawString("iteração (total " + cf.iteracao + ")", ox + w / 2 - 45, oy + h + 15);
        int ly = oy + h + 30;
        g.setColor(Color.GRAY); g.drawString("média", ox, ly);
        g.setColor(new Color(40, 90, 220)); g.drawString("melhor da iteração", ox + 45, ly);
        g.setColor(Color.RED); g.drawString("melhor global", ox + 175, ly);
        g.setColor(new Color(255, 140, 0)); g.drawString("guloso", ox + 265, ly);
    }
}
