"""Rota de recolha de resíduos com Colónia de Formigas.
Uso: python main.py [--formigas 20] [--iteracoes 100] [--alfa 1] [--beta 3] [--rho 0.5] [--png f.png]"""
import argparse
from algoritmo import *


def desenhar_cidades(a, pts):
    a.scatter([p[0] for p in pts], [p[1] for p in pts], c="k", s=25, zorder=3)
    for i, p in enumerate(pts):
        a.annotate(BAIRROS[i], p, textcoords="offset points", xytext=(4, 4), fontsize=7, zorder=4)
    a.set_aspect("equal"); a.grid(alpha=.25)


def desenhar_feromona(a, pts, tau, titulo):
    n = len(pts)
    m = max(tau[i][j] for i in range(n) for j in range(i + 1, n))
    for i in range(n):
        for j in range(i + 1, n):
            f = tau[i][j] / m
            if f > 0.04:
                a.plot([pts[i][0], pts[j][0]], [pts[i][1], pts[j][1]], color="tab:red",
                       alpha=min(1, 0.15 + f), lw=0.5 + 6 * f, zorder=1)
    desenhar_cidades(a, pts); a.set_title(titulo, fontsize=10)


def desenhar_rota(a, pts, rota, titulo, cor):
    r = rota + [rota[0]]
    a.plot([pts[i][0] for i in r], [pts[i][1] for i in r], "-", color=cor, lw=2, zorder=1)
    desenhar_cidades(a, pts); a.set_title(titulo, fontsize=10)


def grafico(pts, res, rota_nn, custo_nn, ficheiro=None):
    import matplotlib
    if ficheiro: matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(2, 3, figsize=(17, 10.5))
    for a, it in zip(ax[0], sorted(res.instantaneos)):
        desenhar_feromona(a, pts, res.instantaneos[it], f"Feromona na iteração {it} (traço grosso = mais feromona)")
    desenhar_rota(ax[1][0], pts, rota_nn, f"Vizinho mais próximo (guloso): {custo_nn:.1f} km", "tab:orange")
    desenhar_rota(ax[1][1], pts, res.melhor_rota, f"Colónia de formigas: {res.melhor_custo:.1f} km", "tab:green")
    c = ax[1][2]
    c.plot(res.hist_media, color="gray", label="média das formigas")
    c.plot(res.hist_iter, color="tab:blue", label="melhor da iteração")
    c.plot(res.hist_global, color="tab:red", lw=2.5, label="melhor global")
    c.axhline(custo_nn, color="tab:orange", ls="--", label="guloso")
    c.set_title("Convergência"); c.set_xlabel("iteração"); c.set_ylabel("comprimento (km)")
    c.legend(fontsize=8); c.grid(alpha=.3)
    plt.tight_layout()
    if ficheiro: fig.savefig(ficheiro, dpi=100); print("Imagem gravada em", ficheiro)
    else: plt.show()


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--formigas", type=int, default=20); p.add_argument("--iteracoes", type=int, default=100)
    p.add_argument("--alfa", type=float, default=1.0); p.add_argument("--beta", type=float, default=3.0)
    p.add_argument("--rho", type=float, default=0.5); p.add_argument("--semente", type=int, default=42)
    p.add_argument("--png")
    a = p.parse_args()
    res = colonia(n_formigas=a.formigas, iteracoes=a.iteracoes, alfa=a.alfa, beta=a.beta, rho=a.rho, semente=a.semente)
    d = matriz_distancias()
    nn = vizinho_mais_proximo(d); custo_nn = custo_rota(nn, d)
    print(f"Parâmetros: formigas={a.formigas} iterações={a.iteracoes} alfa={a.alfa} beta={a.beta} rho={a.rho}\n")
    print("Iteração | melhor da iteração | média | melhor global")
    for i in range(0, a.iteracoes, 10):
        print(f"  {i+1:4d}   |   {res.hist_iter[i]:9.1f}      | {res.hist_media[i]:6.1f} | {res.hist_global[i]:7.1f}")
    print(f"  {a.iteracoes:4d}   |   {res.hist_iter[-1]:9.1f}      | {res.hist_media[-1]:6.1f} | {res.hist_global[-1]:7.1f}")
    print(f"\nVizinho mais próximo: {custo_nn:.1f} km | Colónia de formigas: {res.melhor_custo:.1f} km "
          f"({100 * (1 - res.melhor_custo / custo_nn):.1f}% melhor)")
    print("Rota:", " -> ".join(BAIRROS[i] for i in res.melhor_rota), "->", BAIRROS[res.melhor_rota[0]])
    grafico(PONTOS, res, nn, custo_nn, a.png)
