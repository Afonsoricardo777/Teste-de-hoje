"""Optimização por Colónia de Formigas (Ant Colony Optimization - Ant System de Dorigo)
aplicada à rota de recolha de resíduos entre 15 bairros (Caixeiro Viajante).
As formigas constroem rotas; as melhores deixam mais feromona; a feromona evapora."""
import math
import random

BAIRROS = ["Cazenga", "Viana", "Cacuaco", "Maianga", "Ingombota", "Sambizanga", "Rangel", "Kilamba",
           "Talatona", "Benfica", "Samba", "Mutamba", "Golfe", "Palanca", "Camama"]
# posições fictícias (x, y) em km
PONTOS = [(62, 76), (64, 62), (70, 80), (29, 28), (70, 65), (85, 83), (28, 17), (62, 43), (23, 16), (73, 93), (86, 10), (81, 55), (62, 88), (83, 88), (25, 84)]


class Resultado:
    def __init__(self):
        self.melhor_rota, self.melhor_custo = None, math.inf
        self.hist_iter, self.hist_media, self.hist_global = [], [], []
        self.instantaneos = {}      # iteração -> matriz de feromona nesse momento


def matriz_distancias(pts=PONTOS):
    n = len(pts)
    return [[math.dist(pts[i], pts[j]) for j in range(n)] for i in range(n)]


def custo_rota(rota, d):
    return sum(d[rota[i]][rota[(i + 1) % len(rota)]] for i in range(len(rota)))


def vizinho_mais_proximo(d, inicio=0):
    """Heurística gulosa de referência: vai sempre para o bairro livre mais próximo."""
    rota, livres = [inicio], set(range(len(d))) - {inicio}
    while livres:
        prox = min(livres, key=lambda j: d[rota[-1]][j])
        rota.append(prox)
        livres.remove(prox)
    return rota


def _construir_rota(n, tau, eta, alfa, beta, rng):
    """Uma formiga escolhe o próximo bairro com probabilidade proporcional a tau^alfa * eta^beta."""
    atual = rng.randrange(n)
    rota, livres = [atual], set(range(n)) - {atual}
    while livres:
        cand = list(livres)
        pesos = [(tau[atual][j] ** alfa) * (eta[atual][j] ** beta) for j in cand]
        atual = rng.choices(cand, weights=pesos)[0]
        rota.append(atual)
        livres.remove(atual)
    return rota


def colonia(pts=PONTOS, n_formigas=20, iteracoes=100, alfa=1.0, beta=3.0, rho=0.5, Q=100.0,
            semente=42, instantaneos=(1, 10)):
    """alfa: peso da feromona | beta: peso da distância (visibilidade 1/d)
    rho: taxa de evaporação | Q: quantidade de feromona depositada (Q / comprimento da rota)."""
    rng = random.Random(semente)
    n = len(pts)
    d = matriz_distancias(pts)
    eta = [[0 if i == j else 1.0 / d[i][j] for j in range(n)] for i in range(n)]
    tau = [[1.0] * n for _ in range(n)]
    res = Resultado()
    for it in range(1, iteracoes + 1):
        rotas = [_construir_rota(n, tau, eta, alfa, beta, rng) for _ in range(n_formigas)]
        custos = [custo_rota(r, d) for r in rotas]
        for i in range(n):                                   # 1) evaporação
            for j in range(n):
                tau[i][j] = max(tau[i][j] * (1 - rho), 1e-6)
        for r, c in zip(rotas, custos):                      # 2) depósito: rotas curtas -> mais feromona
            dep = Q / c
            for k in range(n):
                a, b = r[k], r[(k + 1) % n]
                tau[a][b] += dep
                tau[b][a] += dep
        ib = min(range(n_formigas), key=custos.__getitem__)
        if custos[ib] < res.melhor_custo:
            res.melhor_custo, res.melhor_rota = custos[ib], rotas[ib][:]
        res.hist_iter.append(custos[ib])
        res.hist_media.append(sum(custos) / n_formigas)
        res.hist_global.append(res.melhor_custo)
        if it in instantaneos or it == iteracoes:
            res.instantaneos[it] = [l[:] for l in tau]
    return res
