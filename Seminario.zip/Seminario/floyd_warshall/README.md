# Floyd-Warshall — Rede de transportes e centro logístico (Tema 12)

**Aplicação:** rede rodoviária entre 9 cidades (distâncias **ilustrativas**). Calcula a distância mínima entre **todos os pares**,
reconstrói qualquer caminho e escolhe a cidade ideal para um centro logístico (menor soma de distâncias).

**Executar:** Python `cd python && pip install -r requirements.txt && python main.py [--origem Luanda --destino Namibe] [--passos] [--negativo]` |
Java `cd java && mkdir out && javac -encoding UTF-8 -d out src/floydwarshall/*.java && java -cp out floydwarshall.Main`
(opções: `--origem X --destino Y`, `--passos`, `--negativo`, `--png f.png`, `--console`; a janela Java tem seletores de origem/destino).

**Ideia (programação dinâmica):** `dist[i][j] = min(dist[i][j], dist[i][k] + dist[k][j])` para cada vértice intermédio `k`.
Três ciclos aninhados → O(V³). A matriz `prox` permite reconstruir o caminho. Se `dist[i][i] < 0`, há **ciclo negativo**.

| Critério | Conteúdo sugerido |
|---|---|
| Definição e objectivos | Caminhos mais curtos entre todos os pares de vértices num grafo ponderado. |
| Potencialidades | Código curto; aceita pesos negativos; detecta ciclos negativos; uma só execução serve todas as consultas (rotas, centro logístico, fecho transitivo). |
| Limitações | O(V³) tempo e O(V²) memória: inviável para grafos muito grandes; para uma só origem Dijkstra é melhor; sem ciclos negativos é obrigatório para ter resultado válido; grafos esparsos preferem Johnson. |
| Exemplo prático | `algoritmo.py` / `FloydWarshall.java` (`--passos` mostra a matriz a cada `k`). |
| Representação gráfica | Mapa da rede com caminho destacado + mapa de calor da matriz. |
