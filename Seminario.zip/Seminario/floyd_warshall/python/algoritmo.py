"""Floyd-Warshall aplicado a uma rede rodoviária entre cidades (distâncias ILUSTRATIVAS, em km).
Calcula a distância mínima entre TODOS os pares de cidades e permite escolher o melhor
local para um centro logístico (armazém de ajuda humanitária, por exemplo)."""

INF = float("inf")

CIDADES = ["Luanda", "Malanje", "Uíge", "Cabinda", "Benguela", "Lobito", "Huambo", "Lubango", "Namibe"]
# posição aproximada no mapa (x, y) entre 0 e 1, só para desenhar
POSICOES = [(0.22, 0.42), (0.55, 0.40), (0.38, 0.22), (0.12, 0.06), (0.25, 0.68),
            (0.03, 0.58), (0.52, 0.66), (0.42, 0.88), (0.15, 0.93)]
ESTRADAS = [(0, 1, 380), (0, 2, 330), (0, 4, 540), (0, 6, 610), (1, 2, 420), (1, 6, 560),
            (2, 3, 480), (4, 5, 30), (4, 6, 300), (4, 8, 430), (6, 7, 420), (7, 8, 190)]


def floyd_warshall(n, arestas, direcionado=False, mostrar_passos=False):
    """Devolve (dist, prox). prox[i][j] = próximo vértice no caminho mínimo de i para j.
    Complexidade: O(V^3) tempo, O(V^2) memória."""
    dist = [[INF] * n for _ in range(n)]
    prox = [[None] * n for _ in range(n)]
    for i in range(n):
        dist[i][i] = 0
        prox[i][i] = i
    for u, v, w in arestas:
        dist[u][v], prox[u][v] = w, v
        if not direcionado:
            dist[v][u], prox[v][u] = w, u
    for k in range(n):                       # k = vértice intermédio permitido
        for i in range(n):
            for j in range(n):
                if dist[i][k] + dist[k][j] < dist[i][j]:
                    dist[i][j] = dist[i][k] + dist[k][j]
                    prox[i][j] = prox[i][k]
        if mostrar_passos:
            print(f"\n--- após permitir '{CIDADES[k]}' como intermédio (k={k}) ---")
            imprimir_matriz(dist)
    return dist, prox


def caminho(prox, i, j):
    """Reconstrói o caminho mínimo de i para j (lista vazia se não existir)."""
    if prox[i][j] is None:
        return []
    c = [i]
    while i != j:
        i = prox[i][j]
        c.append(i)
    return c


def tem_ciclo_negativo(dist):
    """Se algum vértice chega a si próprio com custo < 0, existe ciclo negativo."""
    return any(dist[i][i] < 0 for i in range(len(dist)))


def centro_logistico(dist):
    """Cidade que minimiza a soma das distâncias a todas as outras."""
    totais = [sum(l) for l in dist]
    i = min(range(len(totais)), key=totais.__getitem__)
    return i, totais[i]


def centro_do_grafo(dist):
    """Cidade que minimiza a distância ao ponto MAIS distante (pior caso)."""
    exc = [max(l) for l in dist]
    i = min(range(len(exc)), key=exc.__getitem__)
    return i, exc[i]


def imprimir_matriz(dist, nomes=CIDADES):
    print(" " * 9 + "".join(f"{n[:7]:>8}" for n in nomes))
    for i, linha in enumerate(dist):
        print(f"{nomes[i][:8]:<9}" + "".join(f"{('INF' if v == INF else int(v)):>8}" for v in linha))
