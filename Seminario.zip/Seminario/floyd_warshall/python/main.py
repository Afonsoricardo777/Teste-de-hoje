"""Rede de transportes com Floyd-Warshall.
Uso: python main.py [--origem Luanda --destino Namibe] [--passos] [--negativo] [--png f.png]"""
import argparse
from algoritmo import *


def grafico(dist, prox, rota, hub, ficheiro=None):
    import matplotlib
    if ficheiro: matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import numpy as np
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(15, 6.5), gridspec_kw={"width_ratios": [1, 1.1]})
    arestas_rota = {frozenset(p) for p in zip(rota, rota[1:])}
    for u, v, w in ESTRADAS:
        (x1, y1), (x2, y2) = POSICOES[u], POSICOES[v]
        no = frozenset((u, v)) in arestas_rota
        a1.plot([x1, x2], [y1, y2], '-', color="orange" if no else "gray", lw=5 if no else 1.8, zorder=1)
        a1.text((x1 + x2) / 2, (y1 + y2) / 2, str(w), fontsize=8, ha="center", va="center",
                bbox=dict(fc="white", ec="none", pad=1), zorder=3)
    for i, (x, y) in enumerate(POSICOES):
        cor = "gold" if i == hub else ("lightgreen" if i in (rota[0], rota[-1]) else "lightblue")
        a1.scatter(x, y, s=900, c=cor, ec="k", zorder=2)
        a1.text(x, y, CIDADES[i], ha="center", va="center", fontsize=8, zorder=4)
    a1.invert_yaxis(); a1.axis("off")
    a1.set_title(f"{CIDADES[rota[0]]} → {CIDADES[rota[-1]]}: {int(dist[rota[0]][rota[-1]])} km "
                 f"via {' > '.join(CIDADES[i] for i in rota)}\n(dourado = centro logístico)", fontsize=10)
    m = np.array(dist)
    a2.imshow(m, cmap="YlOrRd")
    for i in range(len(m)):
        for j in range(len(m)):
            a2.text(j, i, int(m[i][j]), ha="center", va="center", fontsize=8)
    a2.set_xticks(range(len(CIDADES))); a2.set_xticklabels(CIDADES, rotation=45, ha="right", fontsize=8)
    a2.set_yticks(range(len(CIDADES))); a2.set_yticklabels(CIDADES, fontsize=8)
    a2.set_title("Matriz de distâncias mínimas (km) - todos os pares")
    plt.tight_layout()
    if ficheiro: fig.savefig(ficheiro, dpi=110); print("Imagem gravada em", ficheiro)
    else: plt.show()


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--origem", default="Luanda"); p.add_argument("--destino", default="Namibe")
    p.add_argument("--passos", action="store_true"); p.add_argument("--negativo", action="store_true")
    p.add_argument("--png")
    a = p.parse_args()

    if a.negativo:   # demonstração de deteção de ciclo negativo (grafo direcionado)
        d, _ = floyd_warshall(3, [(0, 1, 1), (1, 2, -3), (2, 0, 1)], direcionado=True)
        print("Ciclo negativo detetado?", tem_ciclo_negativo(d)); raise SystemExit

    n = len(CIDADES)
    dist, prox = floyd_warshall(n, ESTRADAS, mostrar_passos=a.passos)
    print("\nMATRIZ FINAL DE DISTÂNCIAS MÍNIMAS (km)"); imprimir_matriz(dist)
    i, j = CIDADES.index(a.origem), CIDADES.index(a.destino)
    rota = caminho(prox, i, j)
    print(f"\nCaminho {a.origem} -> {a.destino}: {' -> '.join(CIDADES[k] for k in rota)} ({dist[i][j]} km)")
    h, tot = centro_logistico(dist); c, exc = centro_do_grafo(dist)
    print(f"Melhor centro logístico (menor soma de distâncias): {CIDADES[h]} ({tot} km no total)")
    print(f"Centro do grafo (menor distância ao mais afastado): {CIDADES[c]} ({exc} km)")
    print("Ciclo negativo?", tem_ciclo_negativo(dist))
    grafico(dist, prox, rota, h, a.png)
