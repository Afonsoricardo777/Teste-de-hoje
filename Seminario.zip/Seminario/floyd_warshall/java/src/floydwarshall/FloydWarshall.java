package floydwarshall;

import java.util.*;

/** Floyd-Warshall: distâncias mínimas entre todos os pares. O(V^3) tempo, O(V^2) memória. */
public class FloydWarshall {
    public static final double INF = Double.POSITIVE_INFINITY;

    public final int n;
    public final double[][] dist;
    public final int[][] prox;   // prox[i][j] = próximo vértice no caminho mínimo i -> j (-1 se não existe)

    public FloydWarshall(int n, int[][] arestas, boolean direcionado, boolean mostrarPassos) {
        this.n = n;
        dist = new double[n][n];
        prox = new int[n][n];
        for (int i = 0; i < n; i++) {
            Arrays.fill(dist[i], INF);
            Arrays.fill(prox[i], -1);
            dist[i][i] = 0; prox[i][i] = i;
        }
        for (int[] e : arestas) {
            dist[e[0]][e[1]] = e[2]; prox[e[0]][e[1]] = e[1];
            if (!direcionado) { dist[e[1]][e[0]] = e[2]; prox[e[1]][e[0]] = e[0]; }
        }
        for (int k = 0; k < n; k++) {                 // k = vértice intermédio permitido
            for (int i = 0; i < n; i++)
                for (int j = 0; j < n; j++)
                    if (dist[i][k] + dist[k][j] < dist[i][j]) {
                        dist[i][j] = dist[i][k] + dist[k][j];
                        prox[i][j] = prox[i][k];
                    }
            if (mostrarPassos) {
                System.out.println("\n--- após permitir '" + Rede.CIDADES[k] + "' como intermédio (k=" + k + ") ---");
                imprimir();
            }
        }
    }

    public List<Integer> caminho(int i, int j) {
        List<Integer> c = new ArrayList<>();
        if (prox[i][j] < 0) return c;
        c.add(i);
        while (i != j) { i = prox[i][j]; c.add(i); }
        return c;
    }

    public boolean temCicloNegativo() {
        for (int i = 0; i < n; i++) if (dist[i][i] < 0) return true;
        return false;
    }

    /** Cidade com menor soma de distâncias a todas as outras (centro logístico). */
    public int centroLogistico() {
        int melhor = 0; double menor = INF;
        for (int i = 0; i < n; i++) {
            double s = 0;
            for (double d : dist[i]) s += d;
            if (s < menor) { menor = s; melhor = i; }
        }
        return melhor;
    }

    public double somaDistancias(int i) { double s = 0; for (double d : dist[i]) s += d; return s; }

    /** Cidade com menor distância ao ponto mais afastado. */
    public int centroDoGrafo() {
        int melhor = 0; double menor = INF;
        for (int i = 0; i < n; i++) {
            double m = 0;
            for (double d : dist[i]) m = Math.max(m, d);
            if (m < menor) { menor = m; melhor = i; }
        }
        return melhor;
    }

    public void imprimir() {
        StringBuilder sb = new StringBuilder(String.format("%9s", ""));
        for (int j = 0; j < n; j++) sb.append(String.format("%8s", Rede.CIDADES[j].substring(0, Math.min(7, Rede.CIDADES[j].length()))));
        System.out.println(sb);
        for (int i = 0; i < n; i++) {
            sb = new StringBuilder(String.format("%-9s", Rede.CIDADES[i].substring(0, Math.min(8, Rede.CIDADES[i].length()))));
            for (int j = 0; j < n; j++) sb.append(String.format("%8s", dist[i][j] == INF ? "INF" : String.valueOf((int) dist[i][j])));
            System.out.println(sb);
        }
    }
}
