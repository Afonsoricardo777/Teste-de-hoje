package floydwarshall;

/** Rede rodoviária entre cidades (distâncias ILUSTRATIVAS em km). */
public class Rede {
    public static final String[] CIDADES = {"Luanda", "Malanje", "Uíge", "Cabinda", "Benguela",
            "Lobito", "Huambo", "Lubango", "Namibe"};
    public static final double[][] POSICOES = {{0.22, 0.42}, {0.55, 0.40}, {0.38, 0.22}, {0.12, 0.06},
            {0.25, 0.68}, {0.03, 0.58}, {0.52, 0.66}, {0.42, 0.88}, {0.15, 0.93}};
    public static final int[][] ESTRADAS = {{0, 1, 380}, {0, 2, 330}, {0, 4, 540}, {0, 6, 610},
            {1, 2, 420}, {1, 6, 560}, {2, 3, 480}, {4, 5, 30}, {4, 6, 300}, {4, 8, 430},
            {6, 7, 420}, {7, 8, 190}};
}
