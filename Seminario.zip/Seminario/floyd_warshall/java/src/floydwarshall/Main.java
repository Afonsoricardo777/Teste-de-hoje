package floydwarshall;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.*;
import java.util.List;

/** java -cp out floydwarshall.Main [--origem X --destino Y] [--passos] [--negativo] [--console] [--png f.png] */
public class Main {
    static String arg(List<String> a, String k, String def) { return a.contains(k) ? a.get(a.indexOf(k) + 1) : def; }

    public static void main(String[] args) throws Exception {
        List<String> a = Arrays.asList(args);
        if (a.contains("--negativo")) {
            FloydWarshall d = new FloydWarshall(3, new int[][]{{0, 1, 1}, {1, 2, -3}, {2, 0, 1}}, true, false);
            System.out.println("Ciclo negativo detetado? " + d.temCicloNegativo());
            return;
        }
        FloydWarshall fw = new FloydWarshall(Rede.CIDADES.length, Rede.ESTRADAS, false, a.contains("--passos"));
        System.out.println("\nMATRIZ FINAL DE DISTÂNCIAS MÍNIMAS (km)");
        fw.imprimir();
        List<String> nomes = Arrays.asList(Rede.CIDADES);
        int o = nomes.indexOf(arg(a, "--origem", "Luanda")), d = nomes.indexOf(arg(a, "--destino", "Namibe"));
        List<Integer> rota = fw.caminho(o, d);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < rota.size(); i++) sb.append(i > 0 ? " -> " : "").append(Rede.CIDADES[rota.get(i)]);
        System.out.printf("%nCaminho: %s (%d km)%n", sb, (int) fw.dist[o][d]);
        int h = fw.centroLogistico(), c = fw.centroDoGrafo();
        System.out.printf("Melhor centro logístico (menor soma de distâncias): %s (%d km no total)%n", Rede.CIDADES[h], (int) fw.somaDistancias(h));
        System.out.printf("Centro do grafo (menor distância ao mais afastado): %s%n", Rede.CIDADES[c]);
        System.out.println("Ciclo negativo? " + fw.temCicloNegativo());

        PainelRede painel = new PainelRede(fw);
        painel.setRota(rota);
        if (a.contains("--png")) {
            painel.setSize(painel.getPreferredSize());
            BufferedImage img = new BufferedImage(painel.getWidth(), painel.getHeight(), BufferedImage.TYPE_INT_RGB);
            painel.paint(img.createGraphics());
            javax.imageio.ImageIO.write(img, "png", new File(arg(a, "--png", "saida.png")));
            System.out.println("Imagem gravada.");
        } else if (!a.contains("--console")) {
            SwingUtilities.invokeLater(() -> {
                JFrame f = new JFrame("Floyd-Warshall - rede de transportes");
                JComboBox<String> cbO = new JComboBox<>(Rede.CIDADES), cbD = new JComboBox<>(Rede.CIDADES);
                cbO.setSelectedIndex(o); cbD.setSelectedIndex(d);
                Runnable atualizar = () -> painel.setRota(fw.caminho(cbO.getSelectedIndex(), cbD.getSelectedIndex()));
                cbO.addActionListener(e -> atualizar.run()); cbD.addActionListener(e -> atualizar.run());
                JPanel topo = new JPanel(new FlowLayout(FlowLayout.LEFT));
                topo.add(new JLabel("Origem:")); topo.add(cbO); topo.add(new JLabel("Destino:")); topo.add(cbD);
                f.add(topo, BorderLayout.NORTH); f.add(painel, BorderLayout.CENTER);
                f.pack(); f.setLocationRelativeTo(null);
                f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); f.setVisible(true);
            });
        }
    }
}
