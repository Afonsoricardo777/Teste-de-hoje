package floydwarshall;

import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.util.List;

/** Esquerda: mapa da rede com o caminho destacado. Direita: mapa de calor da matriz de distâncias. */
public class PainelRede extends JPanel {
    private final FloydWarshall fw;
    private List<Integer> rota = new ArrayList<>();
    private int hub;

    public PainelRede(FloydWarshall fw) {
        this.fw = fw;
        this.hub = fw.centroLogistico();
        setPreferredSize(new Dimension(1150, 600));
        setBackground(Color.WHITE);
    }

    public void setRota(List<Integer> r) { rota = r; repaint(); }

    private int px(int i) { return 40 + (int) (Rede.POSICOES[i][0] * 480); }
    private int py(int i) { return 70 + (int) (Rede.POSICOES[i][1] * 500); }

    @Override
    protected void paintComponent(Graphics g0) {
        super.paintComponent(g0);
        Graphics2D g = (Graphics2D) g0;
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        Set<String> noCaminho = new HashSet<>();
        for (int i = 0; i + 1 < rota.size(); i++) {
            int a = rota.get(i), b = rota.get(i + 1);
            noCaminho.add(Math.min(a, b) + "-" + Math.max(a, b));
        }
        g.setFont(new Font("SansSerif", Font.BOLD, 13));
        g.setColor(Color.BLACK);
        if (!rota.isEmpty()) {
            int o = rota.get(0), d = rota.get(rota.size() - 1);
            g.drawString(Rede.CIDADES[o] + " -> " + Rede.CIDADES[d] + ": " + (int) fw.dist[o][d] + " km", 20, 25);
        }
        g.setFont(new Font("SansSerif", Font.PLAIN, 12));
        g.drawString("Dourado = centro logístico (menor soma de distâncias)", 20, 45);

        for (int[] e : Rede.ESTRADAS) {
            boolean no = noCaminho.contains(Math.min(e[0], e[1]) + "-" + Math.max(e[0], e[1]));
            g.setColor(no ? Color.ORANGE : Color.GRAY);
            g.setStroke(new BasicStroke(no ? 6f : 2f));
            g.drawLine(px(e[0]), py(e[0]), px(e[1]), py(e[1]));
            String t = String.valueOf(e[2]);
            int mx = (px(e[0]) + px(e[1])) / 2, my = (py(e[0]) + py(e[1])) / 2;
            g.setColor(Color.WHITE); g.fillRect(mx - 14, my - 9, 28, 15);
            g.setColor(Color.DARK_GRAY); g.drawString(t, mx - g.getFontMetrics().stringWidth(t) / 2, my + 3);
        }
        for (int i = 0; i < fw.n; i++) {
            boolean ext = !rota.isEmpty() && (i == rota.get(0) || i == rota.get(rota.size() - 1));
            g.setColor(i == hub ? new Color(255, 215, 0) : ext ? new Color(144, 238, 144) : new Color(173, 216, 230));
            g.fillOval(px(i) - 28, py(i) - 28, 56, 56);
            g.setColor(Color.BLACK); g.setStroke(new BasicStroke(1.5f));
            g.drawOval(px(i) - 28, py(i) - 28, 56, 56);
            g.drawString(Rede.CIDADES[i], px(i) - g.getFontMetrics().stringWidth(Rede.CIDADES[i]) / 2, py(i) + 4);
        }

        // mapa de calor da matriz
        int ox = 620, oy = 110, c = 48;
        double max = 0;
        for (double[] l : fw.dist) for (double v : l) if (v != FloydWarshall.INF) max = Math.max(max, v);
        g.setFont(new Font("SansSerif", Font.BOLD, 13));
        g.drawString("Matriz de distâncias mínimas (km) - todos os pares", ox, 40);
        g.setFont(new Font("SansSerif", Font.PLAIN, 10));
        for (int i = 0; i < fw.n; i++) {
            g.setColor(Color.BLACK);
            g.drawString(Rede.CIDADES[i], ox - 55, oy + i * c + c / 2 + 4);
            g.drawString(Rede.CIDADES[i].substring(0, Math.min(6, Rede.CIDADES[i].length())), ox + i * c + 6, oy - 8);
            for (int j = 0; j < fw.n; j++) {
                float f = (float) (fw.dist[i][j] / max);
                g.setColor(new Color(1f, 1f - 0.75f * f, 0.85f - 0.8f * f));
                g.fillRect(ox + j * c, oy + i * c, c, c);
                g.setColor(Color.LIGHT_GRAY); g.drawRect(ox + j * c, oy + i * c, c, c);
                g.setColor(Color.BLACK);
                String t = String.valueOf((int) fw.dist[i][j]);
                g.drawString(t, ox + j * c + c / 2 - g.getFontMetrics().stringWidth(t) / 2, oy + i * c + c / 2 + 4);
            }
        }
    }
}
