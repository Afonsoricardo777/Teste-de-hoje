# Hill Climbing (Subida da Encosta) — Rota de distribuição interativa (Tema 21)

**Aplicação:** optimizar a ordem de visita de pontos de entrega (Caixeiro Viajante), minimizando os km do circuito.

## Java (interface interativa)
`cd java && mkdir out && javac -encoding UTF-8 -d out src/*.java && java -cp out Main`
(sem `package`: copie todos os `.java` de `src` para o `src` do seu IDE e execute `Main`; `--png f.png` grava imagem sem janela).

Na janela: clique no mapa para **adicionar** cidades, arraste para as **mover**, botão direito para **remover**; gere cidades aleatórias;
escolha a **vizinhança** (2-opt ou troca de 2 cidades) e a **estratégia** (melhor vizinho ou primeiro que melhora);
use **Passo** para ver cada movimento no registo, **Executar** para subir até ao óptimo local, **Nova rota aleatória** para um reinício
e **Reinícios automáticos** para repetir várias tentativas. O gráfico mostra a descida do custo de cada tentativa.

## Python (visualização estática)
`cd python && pip install -r requirements.txt && python main.py [--reinicios 8] [--png f.png]`

**Ideia:** parte de uma rota aleatória; em cada passo avalia os vizinhos e move-se para o melhor; pára quando nenhum melhora (**óptimo local**).
Com vários reinícios, algumas tentativas chegam ao melhor valor e outras ficam presas em óptimos piores.

| Critério | Conteúdo sugerido |
|---|---|
| Definição e objectivos | Busca local: melhora iterativamente uma solução movendo-se para o melhor vizinho. |
| Potencialidades | Simples, rápido, pouca memória; não precisa conhecer o espaço todo; bom ponto de partida. |
| Limitações | Fica preso em **óptimos locais**; não garante o óptimo global; depende da solução inicial (daí os reinícios; alternativas: Simulated Annealing, Tabu). Mostre na janela: a mesma instância dá resultados diferentes por tentativa e por vizinhança. |
| Exemplo prático | `HillClimbing.java` / `algoritmo.py`. |
| Representação gráfica | Mapa da rota + melhor rota tracejada + gráfico da descida do custo. |
