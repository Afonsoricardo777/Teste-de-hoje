import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/** Mapa das cidades: clique esquerdo adiciona/arrasta, clique direito remove. */
public class PainelRota extends JPanel {
    private static final int M = 30;
    private final HillClimbing hc;
    private Runnable aoAlterar = () -> { };
    private int arrastando = -1;

    public PainelRota(HillClimbing hc) {
        this.hc = hc;
        setBackground(new Color(240, 240, 240));
        MouseAdapter m = new MouseAdapter() {
            @Override public void mousePressed(MouseEvent e) {
                int i = maisProximo(e.getX(), e.getY(), 14);
                if (SwingUtilities.isRightMouseButton(e)) {
                    if (i >= 0) { hc.remover(i); aoAlterar.run(); }
                } else if (i >= 0) {
                    arrastando = i;
                } else {
                    hc.adicionar(1.0 * (e.getX() - M) * 100 / (getWidth() - 2 * M),
                                 100 - 1.0 * (e.getY() - M) * 100 / (getHeight() - 2 * M));
                    aoAlterar.run();
                }
            }
            @Override public void mouseDragged(MouseEvent e) {
                if (arrastando >= 0) {
                    double[] p = hc.pontos.get(arrastando);
                    p[0] = Math.max(0, Math.min(100, 1.0 * (e.getX() - M) * 100 / (getWidth() - 2 * M)));
                    p[1] = Math.max(0, Math.min(100, 100 - 1.0 * (e.getY() - M) * 100 / (getHeight() - 2 * M)));
                    repaint();
                }
            }
            @Override public void mouseReleased(MouseEvent e) {
                if (arrastando >= 0) { arrastando = -1; hc.reiniciarTudo(); aoAlterar.run(); }
            }
        };
        addMouseListener(m);
        addMouseMotionListener(m);
    }

    public void setAoAlterar(Runnable r) { aoAlterar = r; }

    private int px(double x) { return M + (int) (x * (getWidth() - 2 * M) / 100); }
    private int py(double y) { return M + (int) ((100 - y) * (getHeight() - 2 * M) / 100); }

    private int maisProximo(int x, int y, int raio) {
        int melhor = -1; double menor = raio;
        for (int i = 0; i < hc.pontos.size(); i++) {
            double d = Point.distance(x, y, px(hc.pontos.get(i)[0]), py(hc.pontos.get(i)[1]));
            if (d < menor) { menor = d; melhor = i; }
        }
        return melhor;
    }

    private void desenharRota(Graphics2D g, int[] r, Color cor, float largura, float[] tracejado) {
        g.setColor(cor);
        g.setStroke(tracejado == null ? new BasicStroke(largura)
                : new BasicStroke(largura, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 10f, tracejado, 0f));
        for (int i = 0; i < r.length; i++) {
            double[] a = hc.pontos.get(r[i]), b = hc.pontos.get(r[(i + 1) % r.length]);
            g.drawLine(px(a[0]), py(a[1]), px(b[0]), py(b[1]));
        }
    }

    @Override
    protected void paintComponent(Graphics g0) {
        super.paintComponent(g0);
        Graphics2D g = (Graphics2D) g0;
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        int n = hc.pontos.size();
        g.setFont(new Font("SansSerif", Font.BOLD, 13));
        g.setColor(Color.BLACK);
        g.drawString(n < 3 ? "Clique no mapa para adicionar cidades (mínimo 3)"
                : String.format("Rota actual: %.1f km  |  melhor encontrada: %.1f km", hc.custo, hc.melhorCusto), 10, 18);
        if (n >= 3) {
            if (hc.melhorRota != null && hc.melhorCusto < hc.custo - 1e-9)
                desenharRota(g, hc.melhorRota, new Color(0, 170, 0, 150), 2f, new float[]{6f, 6f});
            desenharRota(g, hc.rota, hc.otimoLocal ? new Color(0, 120, 0) : new Color(40, 90, 220), 3f, null);
        }
        g.setFont(new Font("SansSerif", Font.BOLD, 11));
        for (int i = 0; i < n; i++) {
            int x = px(hc.pontos.get(i)[0]), y = py(hc.pontos.get(i)[1]);
            boolean inicio = n >= 3 && hc.rota.length == n && hc.rota[0] == i;
            g.setColor(inicio ? new Color(0, 170, 0) : Color.BLACK);
            g.fillOval(x - 7, y - 7, 14, 14);
            g.setColor(Color.BLACK);
            g.drawString("P" + (i + 1), x + 9, y - 6);
        }
    }
}
