import java.util.*;

/** Motor do Hill Climbing aplicado ao Caixeiro Viajante (rota de distribuição). */
public class HillClimbing {

    public enum Vizinhanca {
        DOIS_OPT("2-opt (inverter segmento)"), TROCA("Troca de 2 cidades");
        private final String rotulo;
        Vizinhanca(String r) { rotulo = r; }
        @Override public String toString() { return rotulo; }
    }

    public enum Estrategia {
        MELHOR("Melhor vizinho (steepest)"), PRIMEIRO("Primeiro que melhora");
        private final String rotulo;
        Estrategia(String r) { rotulo = r; }
        @Override public String toString() { return rotulo; }
    }

    public final List<double[]> pontos = new ArrayList<>();     // coordenadas em [0,100]
    public int[] rota = new int[0];
    public double custo;
    public final List<List<Double>> historicos = new ArrayList<>();   // um por tentativa
    public int[] melhorRota;
    public double melhorCusto = Double.POSITIVE_INFINITY;
    public boolean otimoLocal;
    public Vizinhanca vizinhanca = Vizinhanca.DOIS_OPT;
    public Estrategia estrategia = Estrategia.MELHOR;
    public String ultimoMovimento = "";
    public int[] rotaInicial = new int[0];
    private final Random rng = new Random(42);

    public double dist(int a, int b) {
        double[] p = pontos.get(a), q = pontos.get(b);
        return Math.hypot(p[0] - q[0], p[1] - q[1]);
    }

    public double custoDe(int[] r) {
        double t = 0;
        for (int i = 0; i < r.length; i++) t += dist(r[i], r[(i + 1) % r.length]);
        return t;
    }

    // ---- gestão dos pontos ----
    public void gerarAleatorios(int n) {
        pontos.clear();
        for (int i = 0; i < n; i++) pontos.add(new double[]{5 + rng.nextInt(91), 5 + rng.nextInt(91)});
        reiniciarTudo();
    }

    public void adicionar(double x, double y) { pontos.add(new double[]{x, y}); reiniciarTudo(); }
    public void remover(int i) { pontos.remove(i); reiniciarTudo(); }
    public void limpar() { pontos.clear(); reiniciarTudo(); }

    public void reiniciarTudo() {
        historicos.clear();
        melhorRota = null;
        melhorCusto = Double.POSITIVE_INFINITY;
        novaRotaAleatoria();
    }

    /** Nova tentativa a partir de uma rota aleatória (reinício). */
    public void novaRotaAleatoria() {
        int n = pontos.size();
        List<Integer> l = new ArrayList<>();
        for (int i = 0; i < n; i++) l.add(i);
        Collections.shuffle(l, rng);
        rota = new int[n];
        for (int i = 0; i < n; i++) rota[i] = l.get(i);
        rotaInicial = rota.clone();
        custo = n > 0 ? custoDe(rota) : 0;
        List<Double> h = new ArrayList<>();
        h.add(custo);
        historicos.add(h);
        otimoLocal = n < 4;
        ultimoMovimento = "Nova rota aleatória (tentativa " + historicos.size() + ")";
        atualizarMelhor();
    }

    private void atualizarMelhor() {
        if (rota.length > 0 && custo < melhorCusto - 1e-9) { melhorCusto = custo; melhorRota = rota.clone(); }
    }

    private int[] aplicar(int[] r, int i, int j) {
        int[] nova = r.clone();
        if (vizinhanca == Vizinhanca.DOIS_OPT) {
            for (int a = i, b = j; a < b; a++, b--) { int t = nova[a]; nova[a] = nova[b]; nova[b] = t; }
        } else {
            int t = nova[i]; nova[i] = nova[j]; nova[j] = t;
        }
        return nova;
    }

    /** Um passo da subida. Devolve false se já estamos num óptimo local. */
    public boolean passo() {
        if (otimoLocal) return false;
        int n = rota.length;
        int[] melhor = null;
        double melhorC = custo;
        int bi = -1, bj = -1;
        busca:
        for (int i = 0; i < n - 1; i++)
            for (int j = i + 1; j < n; j++) {
                int[] viz = aplicar(rota, i, j);
                double c = custoDe(viz);
                if (c < melhorC - 1e-9) {
                    melhorC = c; melhor = viz; bi = i; bj = j;
                    if (estrategia == Estrategia.PRIMEIRO) break busca;
                }
            }
        if (melhor == null) {
            otimoLocal = true;
            ultimoMovimento = String.format("ÓPTIMO LOCAL atingido: %.1f km (nenhum vizinho melhora)", custo);
            return false;
        }
        ultimoMovimento = String.format("%s (i=%d, j=%d): %.1f -> %.1f km",
                vizinhanca == Vizinhanca.DOIS_OPT ? "2-opt" : "troca", bi + 1, bj + 1, custo, melhorC);
        rota = melhor; custo = melhorC;
        historicos.get(historicos.size() - 1).add(custo);
        atualizarMelhor();
        return true;
    }

    public void executarAteOtimo() { while (passo()) { } }

    public int iteracoesAtuais() { return historicos.isEmpty() ? 0 : historicos.get(historicos.size() - 1).size() - 1; }

    public void reiniciosAutomaticos(int k) {
        for (int i = 0; i < k; i++) { novaRotaAleatoria(); executarAteOtimo(); }
    }
}
