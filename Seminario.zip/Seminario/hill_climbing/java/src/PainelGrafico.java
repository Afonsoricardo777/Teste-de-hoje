import javax.swing.*;
import java.awt.*;
import java.util.List;

/** Gráfico da descida do custo: uma linha por tentativa (reinício). */
public class PainelGrafico extends JPanel {
    private final HillClimbing hc;

    public PainelGrafico(HillClimbing hc) {
        this.hc = hc;
        setBackground(Color.WHITE);
        setPreferredSize(new Dimension(420, 280));
    }

    @Override
    protected void paintComponent(Graphics g0) {
        super.paintComponent(g0);
        Graphics2D g = (Graphics2D) g0;
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setFont(new Font("SansSerif", Font.BOLD, 12));
        g.setColor(Color.BLACK);
        g.drawString("Descida do custo (1 linha = 1 tentativa)", 10, 18);
        int ox = 60, oy = 30, w = getWidth() - ox - 15, h = getHeight() - oy - 35;
        g.drawRect(ox, oy, w, h);
        double max = 0, min = Double.MAX_VALUE; int maxIt = 1;
        for (List<Double> l : hc.historicos) {
            for (double c : l) { max = Math.max(max, c); min = Math.min(min, c); }
            maxIt = Math.max(maxIt, l.size() - 1);
        }
        if (max <= min) max = min + 1;
        g.setFont(new Font("SansSerif", Font.PLAIN, 11));
        g.drawString(String.format("%.0f km", max), 8, oy + 10);
        g.drawString(String.format("%.0f km", min), 8, oy + h);
        g.drawString("iterações (máx. " + maxIt + ")", ox + w / 2 - 40, oy + h + 25);
        int t = hc.historicos.size();
        for (int k = 0; k < t; k++) {
            List<Double> l = hc.historicos.get(k);
            g.setColor(Color.getHSBColor((k * 0.17f) % 1f, 0.8f, 0.8f));
            g.setStroke(new BasicStroke(k == t - 1 ? 3f : 1.5f));
            if (l.size() == 1) g.fillOval(ox - 3, oy + (int) ((max - l.get(0)) / (max - min) * h) - 3, 6, 6);
            for (int i = 0; i + 1 < l.size(); i++)
                g.drawLine(ox + i * w / maxIt, oy + (int) ((max - l.get(i)) / (max - min) * h),
                           ox + (i + 1) * w / maxIt, oy + (int) ((max - l.get(i + 1)) / (max - min) * h));
        }
    }
}
