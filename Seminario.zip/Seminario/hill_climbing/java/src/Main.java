import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.Arrays;

/**
 * Compilar: javac -encoding UTF-8 -d out src/*.java
 * Executar: java -cp out Main            (interface gráfica)
 *           java -cp out Main --png f.png (imagem de demonstração, sem janela)
 */
public class Main {

    static void layoutProfundo(Component c) {
        if (c instanceof Container) {
            ((Container) c).doLayout();
            for (Component f : ((Container) c).getComponents()) layoutProfundo(f);
        }
    }

    public static void main(String[] args) throws Exception {
        if (Arrays.asList(args).contains("--png")) {
            System.setProperty("java.awt.headless", "true");
            PainelPrincipal p = new PainelPrincipal();
            p.setSize(1250, 800);
            layoutProfundo(p);
            p.demonstracao();
            System.out.println(p.resumo());
            BufferedImage img = new BufferedImage(1250, 800, BufferedImage.TYPE_INT_RGB);
            Graphics2D g = img.createGraphics();
            g.setColor(Color.WHITE); g.fillRect(0, 0, 1250, 800);
            p.paint(g);
            String f = args[Arrays.asList(args).indexOf("--png") + 1];
            javax.imageio.ImageIO.write(img, "png", new File(f));
            System.out.println("Imagem gravada em " + f);
            return;
        }
        SwingUtilities.invokeLater(() -> {
            JFrame f = new JFrame("Hill Climbing - optimização de rota (interativo)");
            f.setContentPane(new PainelPrincipal());
            f.setSize(1250, 800);
            f.setLocationRelativeTo(null);
            f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            f.setVisible(true);
        });
    }
}
