import javax.swing.*;
import java.awt.*;

/** Janela de controlo do Hill Climbing: cidades, vizinhança, estratégia e execução passo a passo. */
public class PainelPrincipal extends JPanel {

    private final HillClimbing hc = new HillClimbing();
    private final PainelRota mapa = new PainelRota(hc);
    private final PainelGrafico grafico = new PainelGrafico(hc);
    private final JTextArea log = new JTextArea();
    private final JLabel estado = new JLabel(" ");
    private final JSlider velocidade = new JSlider(1, 20, 6);
    private final JSpinner sCidades = new JSpinner(new SpinnerNumberModel(20, 4, 80, 1));
    private final JSpinner sReinicios = new JSpinner(new SpinnerNumberModel(8, 1, 200, 1));
    private final Timer timer = new Timer(100, e -> tique());
    private final JButton pausar = new JButton("Pausar");

    public PainelPrincipal() {
        setLayout(new BorderLayout());

        JPanel l1 = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 4));
        l1.add(new JLabel("Cidades:")); l1.add(sCidades);
        JButton gerar = new JButton("Gerar aleatórias");
        gerar.addActionListener(e -> { parar(); hc.gerarAleatorios((Integer) sCidades.getValue()); atualizar("Novas cidades geradas."); });
        JButton limpar = new JButton("Limpar mapa");
        limpar.addActionListener(e -> { parar(); hc.limpar(); atualizar("Mapa limpo. Clique no mapa para adicionar cidades."); });
        l1.add(gerar); l1.add(limpar);
        JComboBox<HillClimbing.Vizinhanca> cv = new JComboBox<>(HillClimbing.Vizinhanca.values());
        cv.addActionListener(e -> { hc.vizinhanca = (HillClimbing.Vizinhanca) cv.getSelectedItem(); hc.otimoLocal = hc.pontos.size() < 4; atualizar("Vizinhança alterada."); });
        JComboBox<HillClimbing.Estrategia> ce = new JComboBox<>(HillClimbing.Estrategia.values());
        ce.addActionListener(e -> { hc.estrategia = (HillClimbing.Estrategia) ce.getSelectedItem(); atualizar("Estratégia alterada."); });
        l1.add(new JLabel("  Vizinhança:")); l1.add(cv);
        l1.add(new JLabel("Estratégia:")); l1.add(ce);

        JPanel l2 = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 4));
        JButton passo = new JButton("Passo");
        passo.addActionListener(e -> { parar(); hc.passo(); atualizar(hc.ultimoMovimento); });
        JButton exec = new JButton("▶ Executar até ao óptimo local");
        exec.addActionListener(e -> { if (!hc.otimoLocal) { pausar.setText("Pausar"); timer.start(); } });
        pausar.addActionListener(e -> {
            if (timer.isRunning()) { timer.stop(); pausar.setText("Continuar"); }
            else if (!hc.otimoLocal) { timer.start(); pausar.setText("Pausar"); }
        });
        JButton nova = new JButton("Nova rota aleatória (reinício)");
        nova.addActionListener(e -> { parar(); hc.novaRotaAleatoria(); atualizar(hc.ultimoMovimento); });
        l2.add(passo); l2.add(exec); l2.add(pausar); l2.add(nova);
        l2.add(new JLabel("  Velocidade:")); l2.add(velocidade);

        JPanel l3 = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 4));
        l3.add(new JLabel("Reinícios automáticos:")); l3.add(sReinicios);
        JButton auto = new JButton("Executar reinícios (instantâneo)");
        auto.addActionListener(e -> {
            parar(); hc.reiniciosAutomaticos((Integer) sReinicios.getValue());
            atualizar(String.format("%d reinícios concluídos. Melhor rota: %.1f km", (Integer) sReinicios.getValue(), hc.melhorCusto));
        });
        l3.add(auto);
        l3.add(new JLabel("   Clique esq.: adiciona/arrasta cidade | clique dir.: remove"));

        JPanel topo = new JPanel();
        topo.setLayout(new BoxLayout(topo, BoxLayout.Y_AXIS));
        topo.add(l1); topo.add(l2); topo.add(l3);
        add(topo, BorderLayout.NORTH);
        add(mapa, BorderLayout.CENTER);

        log.setEditable(false);
        log.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 11));
        JScrollPane sp = new JScrollPane(log);
        JPanel direita = new JPanel(new BorderLayout());
        direita.add(grafico, BorderLayout.NORTH);
        direita.add(sp, BorderLayout.CENTER);
        direita.setPreferredSize(new Dimension(430, 600));
        add(direita, BorderLayout.EAST);

        estado.setBorder(BorderFactory.createEmptyBorder(4, 8, 6, 8));
        estado.setFont(estado.getFont().deriveFont(Font.BOLD, 13f));
        add(estado, BorderLayout.SOUTH);

        mapa.setAoAlterar(() -> { parar(); atualizar("Cidades alteradas: nova rota aleatória."); });
        hc.gerarAleatorios(20);
        atualizar("Pronto. Use Passo para ver cada movimento, ou Executar.");
    }

    private void parar() { timer.stop(); pausar.setText("Pausar"); }

    private void tique() {
        timer.setDelay(Math.max(15, 600 / velocidade.getValue()));
        if (!hc.passo()) timer.stop();
        atualizar(hc.ultimoMovimento);
    }

    private void atualizar(String mensagem) {
        if (mensagem != null && !mensagem.isEmpty()) log.append(mensagem + "\n");
        log.setCaretPosition(log.getDocument().getLength());
        estado.setText(String.format("Tentativa %d | iteração %d | custo actual %.1f km | melhor %.1f km | %s",
                hc.historicos.size(), hc.iteracoesAtuais(), hc.custo,
                hc.melhorRota == null ? 0.0 : hc.melhorCusto,
                hc.otimoLocal ? "ÓPTIMO LOCAL" : "a subir..."));
        mapa.repaint();
        grafico.repaint();
    }

    /** Usado pela opção --png: executa vários reinícios e mostra o resultado. */
    public void demonstracao() {
        hc.reiniciosAutomaticos(8);
        atualizar("Demonstração: 8 reinícios, melhor " + String.format("%.1f km", hc.melhorCusto));
    }

    public String resumo() { return estado.getText(); }
}
