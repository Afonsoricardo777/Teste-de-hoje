"""Optimização de rota de distribuição com Hill Climbing.
Uso: python main.py [--png f.png] [--reinicios N]"""
import sys
from algoritmo import PONTOS, com_reinicios


def grafico(sols, melhor, ficheiro=None):
    import matplotlib
    if ficheiro: matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(1, 3, figsize=(16, 5))

    def rota(a, r, titulo, cor):
        xs = [PONTOS[i][0] for i in r] + [PONTOS[r[0]][0]]
        ys = [PONTOS[i][1] for i in r] + [PONTOS[r[0]][1]]
        a.plot(xs, ys, '-', color=cor, lw=1.8); a.plot(xs, ys, 'ko', ms=5)
        a.plot(xs[0], ys[0], 'g*', ms=16)
        a.set_title(titulo); a.set_aspect('equal'); a.grid(alpha=.3)

    rota(ax[0], melhor.rota_inicial, f"Rota inicial aleatória: {melhor.historico[0]:.1f} km", "tab:red")
    rota(ax[1], melhor.rota, f"Melhor rota (hill climbing): {melhor.custo:.1f} km", "tab:green")
    for k, s in enumerate(sols):
        ax[2].plot(s.historico, marker='.', label=f"#{k+1}: {s.custo:.1f} km")
    ax[2].set_title("Descida do custo (cada linha = 1 reinício)")
    ax[2].set_xlabel("iteração"); ax[2].set_ylabel("comprimento da rota (km)")
    ax[2].legend(fontsize=7); ax[2].grid(alpha=.3)
    plt.tight_layout()
    if ficheiro: fig.savefig(ficheiro, dpi=110); print("Imagem gravada em", ficheiro)
    else: plt.show()


if __name__ == "__main__":
    n = int(sys.argv[sys.argv.index("--reinicios") + 1]) if "--reinicios" in sys.argv else 8
    sols = com_reinicios(n)
    print("Reinício | custo inicial -> custo final | iterações")
    for k, s in enumerate(sols, 1):
        print(f"   #{k:<2}   |  {s.historico[0]:7.1f} -> {s.custo:7.1f} km      | {len(s.historico) - 1}")
    melhor = min(sols, key=lambda s: s.custo)
    print(f"\nMelhor: {melhor.custo:.1f} km | pior óptimo local: {max(s.custo for s in sols):.1f} km")
    print("Rota:", " -> ".join(f"P{i+1}" for i in melhor.rota), "-> P%d" % (melhor.rota[0] + 1))
    ficheiro = sys.argv[sys.argv.index("--png") + 1] if "--png" in sys.argv else None
    grafico(sols, melhor, ficheiro)
