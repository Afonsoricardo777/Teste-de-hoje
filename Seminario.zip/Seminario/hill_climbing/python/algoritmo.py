"""Hill Climbing (subida da encosta) aplicado à optimização de uma rota de distribuição
(Problema do Caixeiro Viajante). Vizinhança: troca 2-opt (inverter um segmento da rota)."""
import math
import random

# Pontos de entrega (x, y) em km - dados fixos para a demonstração
PONTOS = [(84, 37), (50, 93), (88, 72), (8, 64), (36, 88), (11, 25), (19, 52), (65, 36), (53, 74), (18, 78), (36, 6), (32, 57), (40, 28), (54, 25), (14, 22), (84, 84), (61, 21), (21, 5), (5, 31), (32, 26)]


class Solucao:
    def __init__(self, rota, custo, historico, rota_inicial):
        self.rota, self.custo = rota, custo
        self.historico = historico          # custo em cada iteração (subida)
        self.rota_inicial = rota_inicial


def custo(rota, pts=PONTOS):
    """Comprimento total do circuito fechado."""
    return sum(math.dist(pts[rota[i]], pts[rota[(i + 1) % len(rota)]]) for i in range(len(rota)))


def vizinhos_2opt(rota):
    """Gera todas as rotas vizinhas invertendo o segmento [i..j]."""
    n = len(rota)
    for i in range(n - 1):
        for j in range(i + 1, n):
            yield rota[:i] + rota[i:j + 1][::-1] + rota[j + 1:]


def hill_climbing(rota_inicial, pts=PONTOS):
    """Versão 'steepest-ascent': move sempre para o MELHOR vizinho; pára no óptimo local."""
    rota, atual = rota_inicial[:], custo(rota_inicial, pts)
    historico = [atual]
    while True:
        melhor, melhor_custo = None, atual
        for viz in vizinhos_2opt(rota):
            c = custo(viz, pts)
            if c < melhor_custo - 1e-9:
                melhor, melhor_custo = viz, c
        if melhor is None:                 # nenhum vizinho melhora: óptimo local
            break
        rota, atual = melhor, melhor_custo
        historico.append(atual)
    return Solucao(rota, atual, historico, rota_inicial)


def com_reinicios(n_reinicios=8, semente=42, pts=PONTOS):
    """Random-restart hill climbing: repete a subida a partir de rotas aleatórias."""
    rng = random.Random(semente)
    sols = []
    for _ in range(n_reinicios):
        r = list(range(len(pts)))
        rng.shuffle(r)
        sols.append(hill_climbing(r, pts))
    return sols
